"""Bellman‑Ford negative cycle detection for multi‑hop arbitrage.

This module provides helpers to build a log‑price weighted graph from
existing V2 liquidity pools and to find negative weight cycles using
the classic Bellman‑Ford algorithm.  The graph is built from the
same filtered pool list that the path enumerator uses – honouring
token allowlists, DEX allowlists and minimum liquidity thresholds.

Each directed edge in the graph corresponds to trading a token_in for
token_out on a specific DEX/pool.  The edge weight is the negative
logarithm of the mid‑price after fees (out_per_1_in) which makes
arbitrage cycles correspond to negative weight cycles.  Metadata such
as the DEX identifier and pool address are stored on each edge so
that detected cycles can be converted back into route objects for
quoting and execution.

The primary entry points are:

* :func:`build_log_price_graph` – construct a weighted directed graph
  from a registry of pools and a set of token addresses.
* :func:`find_negative_cycles` – run Bellman‑Ford from a set of base
  tokens and return a list of simple cycles whose total log weight is
  negative.  Cycles are normalised and deduplicated before being
  returned.

It is expected that callers will convert the returned cycles into
routes using their own token metadata (symbol lookups) and run them
through the existing quote/profit calculation pipeline.  This module
contains no blockchain or network dependencies and purely operates on
the in‑memory pool data provided by the Registry.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal
from typing import Dict, List, Optional, Set, Tuple

from core.models import Pair
from discovery.registry import Registry


@dataclass
class WeightedEdge:
    """A directed graph edge with an associated log price weight.

    Attributes
    ----------
    token_in: str
        Lowercased address of the input token.
    token_out: str
        Lowercased address of the output token.
    weight: float
        Edge weight defined as ``-log(rate_after_fee)``.  Negative
        cycles in this graph correspond to profitable arbitrage loops.
    dex: str
        Name of the DEX on which this swap occurs (e.g. pancakeswap_v2).
    pool: str
        Address of the underlying liquidity pool used for this edge.
    rate: float
        Mid‑price after fee for 1 unit of ``token_in`` in units of
        ``token_out``.  Stored for debugging/inspection only.
    fee_bps: int
        Swap fee in basis points applied by the DEX.
    """

    token_in: str
    token_out: str
    weight: float
    dex: str
    pool: str
    rate: float
    fee_bps: int


@dataclass
class Graph:
    """Simple directed graph structure used for Bellman‑Ford.

    The graph stores a set of nodes (token addresses) and a list of
    directed weighted edges.  Edges do not need to be sorted or
    grouped by node; the Bellman‑Ford implementation iterates over
    ``edges`` directly.
    """

    nodes: Set[str]
    edges: List[WeightedEdge]


def _estimate_pool_liquidity_usd(
    pair: Pair,
    *,
    base_addr: str,
    base_price_usd: Decimal,
    decimals_by_addr: Dict[str, int],
    stable_addrs: Set[str],
) -> Optional[Decimal]:
    """Approximate pool liquidity in USD using base/stable anchors.

    This helper replicates the logic from the multi‑hop engine for
    estimating liquidity.  It attempts to infer USD prices for the
    tokens in the pair either from direct stablecoin anchors or via
    the configured base token.  When no price can be inferred the
    function returns ``None``.

    Parameters
    ----------
    pair: Pair
        The liquidity pool to evaluate.
    base_addr: str
        Lowercased address of the base asset (e.g. WBNB).
    base_price_usd: Decimal
        Price of one unit of the base asset in USD.
    decimals_by_addr: Dict[str, int]
        Mapping of lowercased token addresses to their decimals.
    stable_addrs: Set[str]
        Set of token addresses considered stablecoins (USD priced).

    Returns
    -------
    Optional[Decimal]
        Approximate total liquidity of the pool in USD, or ``None``
        if the price cannot be determined.
    """

    t0 = pair.token0.lower()
    t1 = pair.token1.lower()
    dec0 = decimals_by_addr.get(t0)
    dec1 = decimals_by_addr.get(t1)
    if dec0 is None or dec1 is None:
        return None

    price0: Optional[Decimal] = None
    price1: Optional[Decimal] = None
    # Direct stable anchors
    if t0 in stable_addrs:
        price0 = Decimal(1)
    elif t0 == base_addr:
        price0 = base_price_usd
    if t1 in stable_addrs:
        price1 = Decimal(1)
    elif t1 == base_addr:
        price1 = base_price_usd

    # Infer the unknown side via the ratio
    def _infer_price(
        token_addr: str,
        other_addr: str,
        other_price: Decimal,
        reserve_token: int,
        reserve_other: int,
        decimals_token: int,
        decimals_other: int,
    ) -> Optional[Decimal]:
        amt_token = Decimal(reserve_token) / (Decimal(10) ** decimals_token)
        amt_other = Decimal(reserve_other) / (Decimal(10) ** decimals_other)
        if amt_token <= 0 or amt_other <= 0:
            return None
        return (amt_other / amt_token) * other_price

    if price0 is None and price1 is not None:
        price0 = _infer_price(
            t0,
            t1,
            price1,
            pair.reserve0,
            pair.reserve1,
            dec0,
            dec1,
        )
    elif price1 is None and price0 is not None:
        price1 = _infer_price(
            t1,
            t0,
            price0,
            pair.reserve1,
            pair.reserve0,
            dec1,
            dec0,
        )

    if price0 is None or price1 is None:
        return None
    amt0 = Decimal(pair.reserve0) / (Decimal(10) ** dec0)
    amt1 = Decimal(pair.reserve1) / (Decimal(10) ** dec1)
    return amt0 * price0 + amt1 * price1


def build_log_price_graph(
    registry: Registry,
    chain: str,
    tokens: List[str],
    active_dexes: List[str],
    dex_fees: Dict[str, int],
    decimals_by_addr: Dict[str, int],
    *,
    base_addr: str,
    base_price_usd: Decimal,
    stable_addrs: Set[str],
    min_pool_liquidity_usd: Decimal = Decimal(0),
    eps: float = 1e-12,
) -> Graph:
    """Build a weighted directed graph from a list of tokens and pools.

    Each pool in the registry that meets the filtering criteria
    contributes two edges (one in each direction) between its token
    addresses.  Edges are included only if both tokens are in the
    ``tokens`` list, the pool lives on one of the ``active_dexes`` and
    its reserves are positive.  When ``min_pool_liquidity_usd`` is
    greater than zero the function filters out pools whose liquidity
    falls below this threshold using the same estimation as the path
    enumerator.

    Parameters
    ----------
    registry: Registry
        Registry of all discovered pools on the chain.
    chain: str
        Chain identifier (e.g. ``"bsc"``).  Used to match pairs.
    tokens: List[str]
        Lowercased token addresses to include in the graph.
    active_dexes: List[str]
        List of DEX names enabled for arbitrage.
    dex_fees: Dict[str, int]
        Mapping of DEX name to its swap fee in basis points.
    decimals_by_addr: Dict[str, int]
        Mapping of lowercased token addresses to decimals.
    base_addr: str
        Lowercased address of the base asset used for liquidity
        estimation.
    base_price_usd: Decimal
        Price of one unit of the base asset in USD.
    stable_addrs: Set[str]
        Addresses considered pegged to USD (e.g. USDT, BUSD).
    min_pool_liquidity_usd: Decimal, optional
        Pools with approximate liquidity below this value are excluded.
    eps: float, optional
        Lower bound for rate values passed to ``log`` to avoid math
        domain errors.

    Returns
    -------
    Graph
        A graph populated with nodes and weighted edges suitable for
        Bellman‑Ford negative cycle detection.
    """

    token_set = {t.lower() for t in tokens if isinstance(t, str) and len(t) == 42 and t.startswith("0x")}
    nodes: Set[str] = set()
    edges: List[WeightedEdge] = []

    for pair in registry.pairs:
        if pair.chain != chain:
            continue
        if pair.dex not in active_dexes:
            continue
        t0 = pair.token0.lower()
        t1 = pair.token1.lower()
        if t0 not in token_set or t1 not in token_set:
            continue
        # skip pools with zero or negative reserves
        if pair.reserve0 <= 0 or pair.reserve1 <= 0:
            continue
        # Skip pools whose liquidity is below the threshold if specified
        if min_pool_liquidity_usd and min_pool_liquidity_usd > 0:
            liq = _estimate_pool_liquidity_usd(
                pair,
                base_addr=base_addr,
                base_price_usd=base_price_usd,
                decimals_by_addr=decimals_by_addr,
                stable_addrs=stable_addrs,
            )
            if liq is None or liq < min_pool_liquidity_usd:
                continue
        # Look up decimals
        dec0 = decimals_by_addr.get(t0)
        dec1 = decimals_by_addr.get(t1)
        if dec0 is None or dec1 is None or dec0 <= 0 or dec1 <= 0:
            continue
        # Convert reserves to token units
        reserve0 = Decimal(pair.reserve0) / (Decimal(10) ** dec0)
        reserve1 = Decimal(pair.reserve1) / (Decimal(10) ** dec1)
        if reserve0 <= 0 or reserve1 <= 0:
            continue
        fee_bps = dex_fees.get(pair.dex, 0)
        fee_fraction = Decimal(1) - (Decimal(fee_bps) / Decimal(10_000))
        # Build edge t0 -> t1
        rate_fwd = (reserve1 / reserve0) * fee_fraction
        rate_fwd_float = float(rate_fwd) if rate_fwd is not None else 0.0
        rate_fwd_clamped = max(rate_fwd_float, eps)
        weight_fwd = -math.log(rate_fwd_clamped)
        edges.append(
            WeightedEdge(
                token_in=t0,
                token_out=t1,
                weight=weight_fwd,
                dex=pair.dex,
                pool=pair.pair,
                rate=rate_fwd_float,
                fee_bps=fee_bps,
            )
        )
        # Build edge t1 -> t0
        rate_back = (reserve0 / reserve1) * fee_fraction
        rate_back_float = float(rate_back) if rate_back is not None else 0.0
        rate_back_clamped = max(rate_back_float, eps)
        weight_back = -math.log(rate_back_clamped)
        edges.append(
            WeightedEdge(
                token_in=t1,
                token_out=t0,
                weight=weight_back,
                dex=pair.dex,
                pool=pair.pair,
                rate=rate_back_float,
                fee_bps=fee_bps,
            )
        )
        nodes.add(t0)
        nodes.add(t1)

    return Graph(nodes=nodes, edges=edges)


def find_negative_cycles(
    graph: Graph,
    base_tokens: List[str],
    max_cycle_length: int,
    max_cycles: int,
) -> List[Tuple[List[str], List[WeightedEdge]]]:
    """Detect negative cycles reachable from the given base tokens.

    Runs the Bellman‑Ford algorithm from each base token found in
    ``graph.nodes``.  For each source the function detects edges that
    can still be relaxed after ``V - 1`` iterations; such edges lie on
    or lead to negative cycles.  Each detected cycle is reconstructed
    by following predecessor pointers until a repeat node is found.

    Cycles are normalised to have their starting token equal to the
    base token when possible, or otherwise rotated to lexicographically
    smallest token.  Duplicate cycles (including reversed order) are
    eliminated.  Only cycles of length between 2 and
    ``max_cycle_length`` (inclusive) are returned.  The result list
    contains tuples of ``(tokens, edges)`` where ``tokens`` is the
    sequence of token addresses (with the start token repeated at the
    end) and ``edges`` is the aligned list of ``WeightedEdge`` objects
    corresponding to each hop.

    Parameters
    ----------
    graph: Graph
        Weighted directed graph built by :func:`build_log_price_graph`.
    base_tokens: List[str]
        Addresses of tokens to use as sources for Bellman‑Ford.  Only
        tokens present in ``graph.nodes`` are considered.
    max_cycle_length: int
        Maximum allowed number of hops in a cycle.  Cycles longer than
        this are discarded.
    max_cycles: int
        Upper bound on the number of cycles returned by the function.

    Returns
    -------
    List[Tuple[List[str], List[WeightedEdge]]]
        A list of unique cycles represented as a tuple of token
        sequence and corresponding edge sequence.  At most
        ``max_cycles`` cycles are returned.
    """

    # Map node to list of outgoing edges for faster scanning
    # (Not strictly necessary for Bellman‑Ford but convenient for cycle reconstruction)
    negative_cycles: List[Tuple[List[str], List[WeightedEdge]]] = []
    seen_keys: Set[Tuple[Tuple[str, ...], Tuple[str, ...]]] = set()
    nodes = list(graph.nodes)
    for base in base_tokens:
        base_lo = base.lower()
        if base_lo not in graph.nodes:
            continue
        # Initialise distances and predecessor pointers
        dist: Dict[str, float] = {n: float('inf') for n in graph.nodes}
        pred: Dict[str, Optional[str]] = {n: None for n in graph.nodes}
        pred_edge: Dict[str, Optional[WeightedEdge]] = {n: None for n in graph.nodes}
        dist[base_lo] = 0.0
        # Relax edges repeatedly
        for _ in range(len(graph.nodes) - 1):
            updated = False
            for edge in graph.edges:
                u = edge.token_in
                v = edge.token_out
                w = edge.weight
                if dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    pred[v] = u
                    pred_edge[v] = edge
                    updated = True
            if not updated:
                break
        # Check for negative cycles
        for edge in graph.edges:
            u = edge.token_in
            v = edge.token_out
            w = edge.weight
            if dist[u] + w < dist[v]:
                # Potential negative cycle involving node v
                # Follow predecessor chain to find a cycle
                cur = v
                # To ensure we land on the cycle, walk predecessor pointers
                for _ in range(len(graph.nodes)):
                    nxt = pred.get(cur)
                    if nxt is None:
                        break
                    cur = nxt
                # Now cur should be on a cycle (if exists)
                cycle_vertices: List[str] = []
                cycle_edges: List[WeightedEdge] = []
                visited: Set[str] = set()
                x = cur
                while True:
                    if x is None:
                        break
                    if x in visited:
                        # Completed the loop
                        break
                    visited.add(x)
                    # Record vertex and the incoming edge
                    cycle_vertices.append(x)
                    e = pred_edge.get(x)
                    if e is None:
                        # No predecessor info; cannot form cycle
                        cycle_edges.append(None)  # placeholder
                        break
                    cycle_edges.append(e)
                    x = pred.get(x)
                # Require at least 2 vertices to form a cycle
                if len(cycle_vertices) < 2:
                    continue
                # Reverse to get forward order
                cycle_vertices_rev = list(reversed(cycle_vertices))
                cycle_edges_rev = list(reversed(cycle_edges))
                # Align edges so that edge[i] goes from vertex[i] -> vertex[i+1]
                # Shift edges by 1 position
                if len(cycle_edges_rev) != len(cycle_vertices_rev):
                    # If a None placeholder slipped in, skip
                    continue
                edges_seq = cycle_edges_rev[1:] + cycle_edges_rev[:1]
                tokens_seq = cycle_vertices_rev
                # Close the cycle by appending the start node at the end
                tokens_closed = tokens_seq + [tokens_seq[0]]
                # Validate that edges align with tokens
                valid = True
                for i in range(len(edges_seq)):
                    ed = edges_seq[i]
                    if ed.token_in != tokens_seq[i] or ed.token_out != tokens_seq[(i + 1) % len(tokens_seq)]:
                        valid = False
                        break
                if not valid:
                    continue
                # Filter by cycle length
                cycle_len = len(tokens_seq)
                if cycle_len < 2 or cycle_len > max_cycle_length:
                    continue
                # Normalise: rotate so that base token is first if present
                tokens_norm = tokens_closed[:-1]  # exclude duplicate for rotation
                edges_norm = list(edges_seq)
                if base_lo in tokens_norm:
                    idx = tokens_norm.index(base_lo)
                    # rotate
                    tokens_norm = tokens_norm[idx:] + tokens_norm[:idx]
                    edges_norm = edges_norm[idx:] + edges_norm[:idx]
                else:
                    # rotate to lexicographically smallest token address for determinism
                    min_tok = min(tokens_norm)
                    idx = tokens_norm.index(min_tok)
                    tokens_norm = tokens_norm[idx:] + tokens_norm[:idx]
                    edges_norm = edges_norm[idx:] + edges_norm[:idx]
                # Close cycle after rotation
                tokens_norm_closed = tokens_norm + [tokens_norm[0]]
                # Build canonical key (tokens, dexes); include closure for tokens
                dex_seq = tuple(e.dex for e in edges_norm)
                key = (tuple(tokens_norm_closed), dex_seq)
                # Also consider reversed order to deduplicate symmetric cycles
                tokens_rev = list(reversed(tokens_norm))
                tokens_rev_closed = tokens_rev + [tokens_rev[0]]
                edges_rev2 = list(reversed(edges_norm))
                dex_seq_rev = tuple(e.dex for e in edges_rev2)
                key_rev = (tuple(tokens_rev_closed), dex_seq_rev)
                if key in seen_keys or key_rev in seen_keys:
                    continue
                seen_keys.add(key)
                if len(negative_cycles) >= max_cycles:
                    return negative_cycles
                # Append cycle with aligned tokens and edges; close tokens
                negative_cycles.append((tokens_norm_closed, list(edges_norm)))
    return negative_cycles


def _sanity_test() -> None:
    """Run a simple sanity test of the Bellman–Ford cycle detection.

    Constructs a toy graph with three tokens A, B, C and artificial
    rates chosen such that there exists a profitable cycle.  The
    function then runs ``find_negative_cycles`` and prints the
    discovered cycles.  It can be invoked via ``python -m arb.bellman``
    for developer diagnostics.
    """
    # Build toy graph
    tokens = {"a", "b", "c"}
    # Edges: A->B (rate 0.9), B->C (0.9), C->A (1.25)
    e1 = WeightedEdge(token_in="a", token_out="b", weight=-math.log(0.9), dex="toy", pool="p1", rate=0.9, fee_bps=0)
    e2 = WeightedEdge(token_in="b", token_out="c", weight=-math.log(0.9), dex="toy", pool="p2", rate=0.9, fee_bps=0)
    e3 = WeightedEdge(token_in="c", token_out="a", weight=-math.log(1.25), dex="toy", pool="p3", rate=1.25, fee_bps=0)
    graph = Graph(nodes=tokens, edges=[e1, e2, e3])
    cycles = find_negative_cycles(graph, base_tokens=["a"], max_cycle_length=4, max_cycles=5)
    print("Sanity test cycles:")
    for toks, edges in cycles:
        print(" -> ".join(toks))


if __name__ == "__main__":
    _sanity_test()
