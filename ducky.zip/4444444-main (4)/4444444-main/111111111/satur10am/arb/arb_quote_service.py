"""Quote service for constant product (V2) AMMs.

This module computes swap outputs using integer arithmetic to mirror
on-chain logic and avoid floating point precision loss.  Decimal is
used only for human-readable presentation of results.
"""

from __future__ import annotations

from decimal import Decimal, ROUND_DOWN, getcontext
from typing import Dict, List, Optional

from core.models import LegResult, PathQuote
from discovery.registry import Registry

getcontext().prec = 50


def _to_base_units(amount: Decimal, decimals: int) -> int:
    """Convert token units to raw integer base units using floor rounding."""

    scale = Decimal(10) ** decimals
    return int((amount * scale).to_integral_value(rounding=ROUND_DOWN))


def _from_base_units(amount: int, decimals: int) -> Decimal:
    """Convert raw integer base units to token units as Decimal."""

    scale = Decimal(10) ** decimals
    return Decimal(amount) / scale


def get_amount_out_int(amount_in: int, reserve_in: int, reserve_out: int, fee_bps: int) -> int:
    """Integer implementation of the Uniswap V2 getAmountOut formula."""

    if amount_in <= 0 or reserve_in <= 0 or reserve_out <= 0:
        return 0

    fee_adjusted = 10_000 - fee_bps
    numerator = amount_in * fee_adjusted * reserve_out
    denominator = reserve_in * 10_000 + amount_in * fee_adjusted
    if denominator == 0:
        return 0
    return numerator // denominator


def build_address_decimals(tokens_config: Dict[str, Dict[str, object]]) -> Dict[str, int]:
    """Return a mapping of lowercased token addresses to decimals.

    The tokens configuration maps symbols to ``address`` and ``decimals``
    fields.  This helper flattens the mapping for quick lookup.
    """
    out: Dict[str, int] = {}
    for meta in tokens_config.values():
        addr = meta.get("address")
        dec = meta.get("decimals")
        if isinstance(addr, str) and isinstance(dec, int):
            out[addr.lower()] = dec
    return out


def get_path_quote(
    chain: str,
    registry: Registry,
    tokens_config: Dict[str, Dict[str, object]],
    dex_fees: Dict[str, int],
    path_tokens: List[str],
    dex_path: List[str],
    amount_in: Decimal,
    slippage_per_leg: Decimal,
) -> Optional[PathQuote]:
    """Compute the output of a multi-hop route.

    For each hop the function picks the highest liquidity pool on the
    specified DEX, performs integer AMM math in raw token units, applies
    a slippage haircut and returns a :class:`PathQuote` describing the
    route.  If any hop is missing a pool the function returns ``None``.
    """
    if len(path_tokens) < 2 or len(dex_path) != len(path_tokens) - 1:
        return None

    if amount_in <= 0:
        return None

    # Precompute lookups for speed
    addr_by_symbol: Dict[str, str] = {}
    decimals_by_symbol: Dict[str, int] = {}
    for sym, meta in tokens_config.items():
        addr = meta.get("address")
        dec = meta.get("decimals")
        if isinstance(addr, str) and isinstance(dec, int):
            addr_by_symbol[sym] = addr.lower()
            decimals_by_symbol[sym] = dec

    slippage_bps = int((slippage_per_leg * Decimal(10_000)).to_integral_value(rounding=ROUND_DOWN))
    slippage_bps = max(0, min(slippage_bps, 10_000))

    initial_meta = tokens_config.get(path_tokens[0])
    if not initial_meta or not isinstance(initial_meta.get("decimals"), int):
        return None
    base_decimals = int(initial_meta.get("decimals"))
    current_amount_int = _to_base_units(amount_in, base_decimals)
    initial_in_int = current_amount_int
    legs: List[LegResult] = []

    for i in range(len(dex_path)):
        sym_in = path_tokens[i]
        sym_out = path_tokens[i + 1]
        dex = dex_path[i]

        addr_in = addr_by_symbol.get(sym_in)
        addr_out = addr_by_symbol.get(sym_out)
        if addr_in is None or addr_out is None:
            return None

        dec_in = decimals_by_symbol.get(sym_in)
        dec_out = decimals_by_symbol.get(sym_out)
        if dec_in is None or dec_out is None:
            return None

        # Find highest liquidity pair for this hop
        best = registry.get_pair(chain, dex, addr_in, addr_out)
        if best is None:
            return None

        # Reserves in raw integer units
        if addr_in == best.token0.lower():
            reserve_in_int = best.reserve0
            reserve_out_int = best.reserve1
        else:
            reserve_in_int = best.reserve1
            reserve_out_int = best.reserve0

        fee_bps = dex_fees.get(dex, 0)
        out_amt_int = get_amount_out_int(current_amount_int, reserve_in_int, reserve_out_int, fee_bps)

        if slippage_bps > 0:
            out_amt_int = out_amt_int * (10_000 - slippage_bps) // 10_000

        amount_in_dec = _from_base_units(current_amount_int, dec_in)
        amount_out_dec = _from_base_units(out_amt_int, dec_out)
        reserve_in_dec = _from_base_units(reserve_in_int, dec_in)
        reserve_out_dec = _from_base_units(reserve_out_int, dec_out)

        leg = LegResult(
            token_in=sym_in,
            token_out=sym_out,
            dex=dex,
            amount_in=amount_in_dec,
            amount_out=amount_out_dec,
            reserve_in=reserve_in_dec,
            reserve_out=reserve_out_dec,
            amount_in_raw=current_amount_int,
            amount_out_raw=out_amt_int,
            reserve_in_raw=reserve_in_int,
            reserve_out_raw=reserve_out_int,
            pair_address=best.pair,
            pair_last_updated=getattr(best, "last_updated", 0.0),
            fee_bps=fee_bps,
        )
        legs.append(leg)
        current_amount_int = out_amt_int

        if current_amount_int <= 0:
            return None

    final_amount_dec = _from_base_units(current_amount_int, base_decimals)
    initial_amount_dec = _from_base_units(initial_in_int, base_decimals)
    spread = (
        (final_amount_dec - initial_amount_dec) / initial_amount_dec
        if initial_amount_dec > 0
        else Decimal(0)
    )
    return PathQuote(
        path_tokens=path_tokens,
        dex_path=dex_path,
        amount_in=initial_amount_dec,
        amount_out=final_amount_dec,
        spread_fraction=spread,
        amount_in_raw=initial_in_int,
        amount_out_raw=current_amount_int,
        legs=legs,
    )
