import logging
from typing import List, Optional, Set
from dextools_python import DextoolsAPIV2

log = logging.getLogger(__name__)


# -------------------------------------------------------------
# Helpers
# -------------------------------------------------------------
def _norm(addr: Optional[str]) -> Optional[str]:
    """
    Normalize token address to 0x + 40 hex chars.
    Returns None if invalid.
    """
    if not isinstance(addr, str):
        return None
    addr = addr.strip().lower()
    if addr.startswith("0x") and len(addr) == 42:
        return addr
    return None


# -------------------------------------------------------------
# DexTools Trending Universe Builder (BSC only, SDK only)
# -------------------------------------------------------------
def fetch_dextools_universe_bsc(
    api_key: str,
    limit: int = 50
) -> List[str]:
    """
    DexTools-only trending universe builder for BSC using the official SDK.
    - No REST fallbacks
    - No DexScreener fallback
    - No hotpairs samples
    - Deterministic, fast, and clean

    Returns a list of token addresses (strings).
    """

    if not api_key:
        log.error("[UNIVERSE][TRENDING][DEXTOOLS] Missing api_key")
        return []

    log.info(
        "[UNIVERSE][TRENDING][DEXTOOLS] Initializing SDK client (plan=trial)"
    )

    # ---------------------------------------------------------
    # Initialize SDK (MUST NOT pass unsupported arguments)
    # ---------------------------------------------------------
    try:
        sdk = DextoolsAPIV2(api_key=api_key, plan="trial")
    except Exception as exc:
        log.error(
            "[UNIVERSE][TRENDING][DEXTOOLS] Failed to initialize DextoolsAPIV2: %s",
            exc,
        )
        return []

    # ---------------------------------------------------------
    # Request hot pools
    # ---------------------------------------------------------
    try:
        resp = sdk.get_ranking_hotpools("bsc")
    except Exception as exc:
        log.error(
            "[UNIVERSE][TRENDING][DEXTOOLS] Hotpools request failed: %s",
            exc,
        )
        return []

    pools = resp.get("data")
    if not isinstance(pools, list) or not pools:
        log.warning(
            "[UNIVERSE][TRENDING][DEXTOOLS] Empty response or unexpected format from DexTools SDK"
        )
        return []

    # ---------------------------------------------------------
    # Extract tokens
    # ---------------------------------------------------------
    tokens: Set[str] = set()

    for pool in pools:
        main = pool.get("mainToken", {})
        side = pool.get("sideToken", {})

        a = _norm(main.get("address"))
        b = _norm(side.get("address"))

        if a:
            tokens.add(a)
        if b:
            tokens.add(b)

        if 0 < limit <= len(tokens):
            break

    final = sorted(tokens)

    log.info(
        "[UNIVERSE][TRENDING][DEXTOOLS] Final token count from hotpools = %d",
        len(final),
    )

    return final


# -------------------------------------------------------------
# Self-test block
# -------------------------------------------------------------
if __name__ == "__main__":
    print("Running DexTools trending universe self-test...")
    test_tokens = fetch_dextools_universe_bsc(
        api_key="REPLACE_ME",
        limit=20,
    )
    print("Received:", len(test_tokens))
    for t in test_tokens[:10]:
        print(" -", t)
