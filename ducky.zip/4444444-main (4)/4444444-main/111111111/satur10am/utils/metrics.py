"""Lightweight in-process metrics helper.

This module provides a minimal counter registry for debugging and
operational observability without external dependencies. Counters are
kept in-memory only and periodically logged by the caller.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict
from typing import Dict, Tuple

log = logging.getLogger(__name__)


class Metrics:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counters: Dict[Tuple[str, Tuple[Tuple[str, str], ...]], int] = defaultdict(int)
        self._ticks = 0
        self._last_log_ts = 0.0

    def inc(self, name: str, amount: int = 1, labels: Dict[str, str] | None = None) -> None:
        lbl_tuple: Tuple[Tuple[str, str], ...] = tuple(sorted((labels or {}).items()))
        with self._lock:
            self._counters[(name, lbl_tuple)] += amount

    def tick(self) -> None:
        with self._lock:
            self._ticks += 1

    def summary(self) -> Dict[str, int]:
        with self._lock:
            flat: Dict[str, int] = {}
            for (name, labels), value in self._counters.items():
                label_str = ",".join([f"{k}={v}" for k, v in labels])
                key = name if not label_str else f"{name}[{label_str}]"
                flat[key] = value
            flat["ticks"] = self._ticks
            return flat

    def maybe_log(self, interval: int = 20) -> None:
        now = time.time()
        if now - self._last_log_ts < interval:
            return
        self._last_log_ts = now
        summary = self.summary()
        parts = [f"{k}={v}" for k, v in sorted(summary.items())]
        log.info("[metrics] %s", " ".join(parts))


auto_metrics = Metrics()
