"""Telegram notification helper for trade/PnL alerts."""

from __future__ import annotations

import logging
from typing import Optional

import requests

log = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, config: dict, logger: Optional[logging.Logger] = None) -> None:
        self.log = logger or log
        tg_cfg = (config or {}).get("telegram", {}) if isinstance(config, dict) else {}

        enabled = bool(tg_cfg.get("enabled", False))
        bot_token = tg_cfg.get("bot_token") or ""
        chat_id = tg_cfg.get("chat_id") or ""

        if not enabled or not bot_token or not chat_id:
            self.log.warning("[telegram] Disabled: missing token/chat_id or enabled flag false")
            self.enabled = False
        else:
            self.enabled = True

        self.bot_token = bot_token
        self.chat_id = chat_id
        self.health_enabled = bool(tg_cfg.get("health_enabled", True))
        self.timeout = float(tg_cfg.get("timeout", 5.0))

    def _can_send(self) -> bool:
        return bool(self.enabled and self.bot_token and self.chat_id)

    def _send(self, text: str) -> None:
        if not self._can_send():
            return
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "Markdown",
        }
        try:
            resp = requests.post(url, json=payload, timeout=self.timeout)
            if not resp.ok:
                self.log.warning(
                    "[telegram] Failed to send message (status=%s): %s",
                    resp.status_code,
                    resp.text,
                )
        except Exception as exc:  # pragma: no cover - best-effort
            self.log.warning("[telegram] Error sending message: %s", exc)

    @staticmethod
    def _short_tx(tx_hash: Optional[str]) -> str:
        if not tx_hash:
            return "n/a"
        tx = str(tx_hash)
        if len(tx) <= 12:
            return tx
        return f"{tx[:8]}…{tx[-6:]}"

    def send_trade_pnl(self, trade: dict) -> None:
        """Send a short PnL summary for an executed trade."""

        if not self._can_send():
            return

        try:
            status = str(trade.get("status", "unknown"))
            net_usd = float(trade.get("net_usd", 0.0) or 0.0)
            route_key = trade.get("route_key") or ""
            chain = trade.get("chain", "bsc")
            tx_hash = self._short_tx(trade.get("tx_hash"))
            message = (
                f"🚀 Trade on {chain}\n"
                f"Route: `{route_key}`\n"
                f"Status: {status}\n"
                f"Net USD: {net_usd:.2f}\n"
                f"Tx: {tx_hash}"
            )
            self._send(message)
        except Exception as exc:  # pragma: no cover - best-effort
            self.log.warning("[telegram] Failed to send trade PnL: %s", exc)

    def send_health_summary(self, health: dict) -> None:
        """Send periodic health metrics."""

        if not self._can_send() or not self.health_enabled:
            return
        try:
            parts = []
            for key in [
                "ticks",
                "rpc_calls",
                "simulations_run",
                "simulations_failed",
                "ws_pair_events_received",
                "ws_mempool_events_received",
                "mempool_tx_decoded",
                "routes_banned",
                "executions_sent",
                "executions_failed",
                "pending_swaps_active",
                "profit24h",
                "rpc_unstable",
                "in_cooldown",
                "consecutive_failures",
            ]:
                if key in health:
                    parts.append(f"{key}={health.get(key)}")
            if not parts:
                parts = [f"{k}={v}" for k, v in sorted((health or {}).items())]
            self._send("📈 Health: " + " ".join(parts))
        except Exception as exc:  # pragma: no cover - best-effort
            self.log.warning("[telegram] Failed to send health summary: %s", exc)

    def send_kill_switch_alert(self, reason: str, cooldown_minutes: int) -> None:
        """Stub kill-switch alert (Phase 2 will wire trigger)."""

        if not self._can_send():
            return
        try:
            message = (
                "[KILL SWITCH] "
                f"Reason: {reason}\n"
                f"Cooldown: {int(cooldown_minutes)} minutes"
            )
            self._send(message)
        except Exception as exc:  # pragma: no cover - best-effort
            self.log.warning("[telegram] Failed to send kill-switch alert: %s", exc)

    def send_risk_alert(self, message: str) -> None:
        """Generic risk alert channel."""

        if not self._can_send():
            return
        try:
            self._send(f"⚠️ Risk alert: {message}")
        except Exception as exc:  # pragma: no cover - best-effort
            self.log.warning("[telegram] Failed to send risk alert: %s", exc)
