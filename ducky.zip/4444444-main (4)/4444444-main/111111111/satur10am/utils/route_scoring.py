from __future__ import annotations

import math
import time
from decimal import Decimal
from typing import Dict, Iterable, List, Tuple

from utils.route_history import RouteHistory


def _as_decimal(value) -> Decimal:
    try:
        return Decimal(str(value))
    except Exception:
        return Decimal(0)


def compute_route_score_from_records(records: Iterable[Dict], *, max_age_sec: float = 86400, tau: float = 14_400.0) -> float:
    now = time.time()
    score = 0.0
    for rec in records:
        ts_raw = rec.get("timestamp")
        try:
            ts = float(ts_raw)
        except Exception:
            try:
                ts = float(_as_decimal(ts_raw))
            except Exception:
                continue
        if now - ts > max_age_sec:
            continue
        age = max(now - ts, 0.0)
        weight = math.exp(-age / max(tau, 1.0))
        net_usd = _as_decimal(rec.get("net_usd"))
        profit_bps = _as_decimal(rec.get("profit_bps"))
        delta = 0.0
        if net_usd > 0:
            delta += 2.0
        elif net_usd == 0 and profit_bps > 0:
            delta += 1.0
        elif net_usd < 0:
            delta -= 2.0
        if rec.get("live_verified") and net_usd <= 0:
            delta -= 1.0
        execution_result = str(rec.get("execution_result")) if rec.get("execution_result") is not None else ""
        if execution_result in {"risk_blocked", "skipped"}:
            delta -= 1.0
        score += delta * weight
    return float(max(-10.0, min(10.0, score)))


def get_route_score(
    *,
    chain: str,
    route_key: str,
    history: RouteHistory,
    max_age_sec: float = 86_400,
    tau: float = 14_400.0,
) -> float:
    records = history.get_by_route_key(chain=chain, route_key=route_key, max_age_sec=max_age_sec)
    if not records:
        return 0.0
    return compute_route_score_from_records(records, max_age_sec=max_age_sec, tau=tau)


def suggest_route_notional_usd(
    chain: str,
    route_key: str,
    history: RouteHistory,
    base_min_notional_usd: Decimal,
    base_max_notional_usd: Decimal,
    lookback_sec: float,
    max_multiplier: float,
) -> Tuple[Decimal, Decimal]:
    try:
        records = history.get_by_route_key(chain=chain, route_key=route_key, max_age_sec=lookback_sec, limit=200)
    except Exception:
        records = []

    base_min = Decimal(base_min_notional_usd)
    base_max = Decimal(base_max_notional_usd)

    if not records:
        return base_min, base_max

    notionals: List[Tuple[Decimal, Decimal]] = []
    for rec in records:
        notional = rec.get("notional_usd")
        if notional is None:
            amt_in = rec.get("amount_in_base")
            base_price = rec.get("base_price_usd")
            if amt_in is not None and base_price is not None:
                notional = _as_decimal(amt_in) * _as_decimal(base_price)
        if notional is None:
            continue
        notionals.append((_as_decimal(notional), _as_decimal(rec.get("net_usd"))))

    if not notionals:
        return base_min, base_max

    profitable_sizes = [n for n, net in notionals if net > 0]
    losing_sizes = [n for n, net in notionals if net <= 0]

    adj_min = base_min
    adj_max = base_max
    multiplier_cap = Decimal(str(max_multiplier))
    if profitable_sizes:
        median_profitable = sorted(profitable_sizes)[len(profitable_sizes) // 2]
        adj_max = min(base_max * multiplier_cap, max(base_max, median_profitable * Decimal("1.5")))
    if losing_sizes:
        max_loss_size = max(losing_sizes)
        adj_max = min(adj_max, max(base_min, max_loss_size * Decimal("0.8")))

    if adj_max < adj_min:
        adj_max = adj_min

    return max(adj_min, Decimal("0.01")), max(adj_max, Decimal("0.01"))
