"""Mathematical helpers for AMM arbitrage.

This module houses standalone functions used by various components of
the bot.  Keeping mathematical routines here avoids circular
dependencies and makes unit testing easier.  It currently exposes
only a constant product swap calculation but can be extended with
additional primitives (e.g. price normalisation or slippage
adjustments) in the future.
"""

from __future__ import annotations

from decimal import Decimal, getcontext

# Increase precision to handle very large reserve values.  Without a
# sufficiently high precision the Decimal division may lose accuracy
# when reserves are on the order of 1e27 (common for WBNB/USDT pools).
getcontext().prec = 78


def get_amount_out(amount_in: Decimal, reserve_in: Decimal, reserve_out: Decimal, fee_bps: int) -> Decimal:
    """Compute the output amount for a constant product swap.

    This function implements the Uniswap V2 formula:

    .. math::

        amount\_out = \frac{amount\_in\_with\_fee \times reserve\_out}{reserve\_in + amount\_in\_with\_fee}

    where ``amount_in_with_fee = amount_in * (1 - fee_bps/10000)``.

    Parameters
    ----------
    amount_in: Decimal
        Quantity of token entering the pool, in token units.
    reserve_in: Decimal
        Reserve of the input token in the pool, in token units.
    reserve_out: Decimal
        Reserve of the output token in the pool, in token units.
    fee_bps: int
        Swap fee in basis points (e.g. 25 for a 0.25% fee).

    Returns
    -------
    Decimal
        The amount of output token received, or ``Decimal(0)`` if
        reserves or input are non‑positive.
    """
    if amount_in <= 0 or reserve_in <= 0 or reserve_out <= 0:
        return Decimal(0)
    fee_fraction = Decimal(fee_bps) / Decimal(10_000)
    amount_in_with_fee = amount_in * (Decimal(1) - fee_fraction)
    numerator = amount_in_with_fee * reserve_out
    denominator = reserve_in + amount_in_with_fee
    if denominator == 0:
        return Decimal(0)
    return numerator / denominator