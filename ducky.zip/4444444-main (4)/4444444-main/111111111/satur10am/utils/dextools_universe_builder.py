"""Compatibility wrapper for the trending universe builder.

Calls are forwarded to :func:`utils.trending_universe_builder.fetch_trending_bsc_tokens`
to keep legacy imports working. DexTools is the preferred provider and
is invoked via the official SDK when an API key is provided either
directly or via the ``DEXTOOLS_API_KEY`` environment variable.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from .trending_universe_builder import fetch_trending_bsc_tokens

log = logging.getLogger(__name__)


def fetch_top_bsc_tokens_from_dextools(
    limit: int,
    api_key: str = "",
    *,
    min_volume_usd: float = 0.0,
    max_pages: int = 1,
    provider: str = "dextools",
    **kwargs: object,
) -> List[str]:
    """Return a list of hot BSC token addresses via the trending builder.

    This wrapper exists purely for backwards compatibility with older
    Universe code that still expects a "DexTools"-named function. The
    real implementation now lives in :func:`fetch_trending_bsc_tokens`
    and uses DexTools via the official SDK with DexScreener as a
    fallback provider.

    Parameters
    ----------
    limit:
        Maximum number of token addresses to return after
        deduplication. Values <= 0 mean “no explicit limit”.
    api_key:
        DexTools API key. If omitted the :envvar:`DEXTOOLS_API_KEY`
        environment variable will be consulted inside the trending
        builder.
    min_volume_usd:
        Minimum 24h USD volume a pool must have to contribute its
        tokens to the universe. If 0 or less, no volume filter is
        applied.
    max_pages:
        Retained for compatibility but not currently used by the
        DexScreener-based implementation. You can safely pass any
        integer here; it is forwarded to :func:`fetch_trending_bsc_tokens`.
    provider:
        Logical provider name. Historically this was ``"dextools"``;
        we normalise anything other than ``"dexscreener"`` to
        ``"dexscreener"`` internally so that callers do not have to
        change.
    **kwargs:
        Ignored. Allows older call-sites to pass extra arguments
        without breaking.

    Returns
    -------
    List[str]
        List of lowercase BSC token contract addresses (0x-prefixed,
        42 chars). May be empty if both the remote API and local sample
        data fail.
    """
    prov = str(provider or "dextools").lower()

    tokens = fetch_trending_bsc_tokens(
        limit=limit,
        min_volume_usd=min_volume_usd,
        max_pages=max_pages,
        provider=prov,
        api_key=api_key,
    )
    if not tokens:
        log.warning(
            "[UNIVERSE][TRENDING][DEXTOOLS] DexTools/DexScreener returned no tokens; using fallback"
        )
    return tokens
