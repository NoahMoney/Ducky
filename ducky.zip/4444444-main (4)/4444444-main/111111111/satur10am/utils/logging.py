"""Basic logging configuration helper.

Centralising logging setup allows the project to avoid repeated
boilerplate across modules.  The ``setup_logging`` function configures
the root logger with a simple formatter that includes a timestamp,
log level and message.  Individual modules can obtain child loggers
via ``logging.getLogger(__name__)`` once the root configuration has
been established.
"""

from __future__ import annotations

import logging
import sys
from typing import Optional


def setup_logging(level: int = logging.INFO, stream: Optional[object] = None) -> None:
    """Configure the root logger with a standard format.

    This helper should be called once at program start before any
    module attempts to fetch a logger.  The default configuration
    writes to ``sys.stderr`` with ISO‑8601 timestamps.  Calling it
    multiple times has no effect beyond the first invocation.

    Parameters
    ----------
    level: int, optional
        Logging level to use.  Defaults to ``logging.INFO``.
    stream: file‑like object, optional
        Stream to write log messages to.  If omitted, ``sys.stderr`` is
        used.  This argument exists to facilitate unit testing.
    """
    if logging.getLogger().handlers:
        # Logger already configured; do not duplicate handlers.
        return
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    datefmt = "%Y-%m-%dT%H:%M:%S"
    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))
    root = logging.getLogger()
    root.setLevel(level)
    root.addHandler(handler)