from __future__ import annotations

import json
import logging
import time
from collections import deque
from pathlib import Path
from typing import Deque, Dict, Iterable, List, Optional

log = logging.getLogger(__name__)


def _extract_timestamp(value) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            try:
                from datetime import datetime

                return datetime.fromisoformat(value).timestamp()
            except Exception:
                return None
    return None


class PnLStore:
    """In-memory PnL tracker with optional JSONL persistence."""

    def __init__(self, store_path: str | Path | None = None, config: Optional[Dict] = None) -> None:
        cfg = config or {}
        pnl_cfg = cfg.get("pnl") if isinstance(cfg.get("pnl"), dict) else cfg
        pnl_cfg = pnl_cfg or {}

        self.recent_window_sec = int(pnl_cfg.get("recent_window_sec", 86_400))
        self.max_trades_in_memory = int(pnl_cfg.get("max_trades_in_memory", 5_000))

        if store_path is None:
            store_path = cfg.get("pnl_store_path", "data/pnl_records.jsonl")
        self.path = Path(store_path)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as exc:  # pragma: no cover - filesystem guard
            log.warning("[pnl] Failed to ensure data directory %s: %s", self.path.parent, exc)

        self.trades: Deque[dict] = deque(maxlen=self.max_trades_in_memory)
        self._load_from_disk()

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------
    def _iter_records(self) -> Iterable[dict]:
        if not self.path.exists():
            return []
        try:
            with self.path.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError:
                        log.warning("[pnl] Skipping malformed line in %s", self.path)
                        continue
        except Exception as exc:  # pragma: no cover - filesystem guard
            log.warning("[pnl] Failed to read %s: %s", self.path, exc)
        return []

    def _load_from_disk(self) -> None:
        cutoff = time.time() - self.recent_window_sec
        for rec in self._iter_records():
            ts = _extract_timestamp(rec.get("timestamp"))
            if ts is None or ts < cutoff:
                continue
            self.trades.append(rec)

    def _persist(self, record: dict) -> None:
        try:
            line = json.dumps(record, default=str)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("[pnl] Failed to serialise trade record: %s", exc)
            return
        try:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except Exception as exc:  # pragma: no cover - filesystem guard
            log.warning("[pnl] Failed to append trade record: %s", exc)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def record_trade(self, trade: dict) -> None:
        if not isinstance(trade, dict):
            log.warning("[pnl] Ignoring non-dict record: %s", trade)
            return

        record = dict(trade)
        record.setdefault("timestamp", time.time())
        record.setdefault("route_key", "unknown")
        record.setdefault("chain", "unknown")
        record.setdefault("net_usd", 0.0)
        record.setdefault("status", "unknown")
        record.setdefault("dex_path", [])
        record.setdefault("tokens", [])

        self.trades.append(record)
        self._persist(record)

    def get_recent_trades(self, chain: Optional[str], window_sec: int) -> List[dict]:
        cutoff = time.time() - window_sec
        filtered = [
            t
            for t in self.trades
            if (chain is None or t.get("chain") == chain)
            and _extract_timestamp(t.get("timestamp"))
            and _extract_timestamp(t.get("timestamp")) >= cutoff
        ]
        filtered.sort(key=lambda x: _extract_timestamp(x.get("timestamp")) or 0, reverse=True)
        return filtered

    def get_24h_pnl(self, chain: Optional[str] = None) -> Dict[str, float | int]:
        window_sec = self.recent_window_sec or 86_400
        recent = self.get_recent_trades(chain, window_sec)
        wins = sum(1 for t in recent if float(t.get("net_usd", 0)) > 0)
        losses = sum(1 for t in recent if float(t.get("net_usd", 0)) < 0)
        breakeven = sum(1 for t in recent if float(t.get("net_usd", 0)) == 0)
        net_usd = sum(float(t.get("net_usd", 0)) for t in recent)
        return {
            "net_usd": net_usd,
            "wins": wins,
            "losses": losses,
            "breakeven": breakeven,
            "total_trades": len(recent),
        }

    def get_global_stats(self) -> Dict[str, float | int]:
        pnl_24h = self.get_24h_pnl(chain=None)
        return {"net_usd": pnl_24h.get("net_usd", 0.0), "total_trades": pnl_24h.get("total_trades", 0)}

