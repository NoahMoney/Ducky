from __future__ import annotations

import logging
import time
from typing import Dict, Optional, Tuple

from utils.pnl_store import PnLStore

log = logging.getLogger(__name__)

_kill_cfg: Dict[str, object] = {}
_cooldown_minutes: int = 60
_cooldown_until_ts: float = 0.0
_last_kill_reason: Optional[str] = None
_last_trigger_ts: float = 0.0


def _load_kill_cfg(config: Dict[str, object]) -> Dict[str, object]:
    cfg = config or {}
    if isinstance(cfg, dict) and isinstance(cfg.get("kill_switch"), dict):
        cfg = cfg.get("kill_switch", {})
    if isinstance(cfg, dict) and isinstance(cfg.get("risk_limits"), dict):
        cfg = cfg.get("risk_limits", {})

    defaults = {
        "max_daily_loss_usd": 100.0,
        "max_consecutive_failures": 10,
        "ws_offline_threshold_sec": 180,
        "cooldown_minutes": 60,
    }
    merged = defaults.copy()
    if isinstance(cfg, dict):
        for k, v in cfg.items():
            if v is not None:
                merged[k] = v
    return merged


def configure_kill_switch(config: Dict[str, object]) -> None:
    global _kill_cfg, _cooldown_minutes, _cooldown_until_ts, _last_kill_reason, _last_trigger_ts
    _kill_cfg = _load_kill_cfg(config or {})
    _cooldown_minutes = int(_kill_cfg.get("cooldown_minutes", 60) or 60)
    _cooldown_until_ts = 0.0
    _last_kill_reason = None
    _last_trigger_ts = 0.0


def evaluate_global_limits(pnl_store: PnLStore, state: Dict[str, object]) -> Tuple[bool, str]:
    """Examine global state and config and return (ok, reason)."""

    cfg = _kill_cfg or _load_kill_cfg({})

    pnl_24h = state.get("pnl_24h")
    if pnl_24h is None and pnl_store:
        try:
            pnl_24h = pnl_store.get_24h_pnl()
        except Exception:  # pragma: no cover - defensive
            pnl_24h = 0.0
    pnl_value = 0.0
    if isinstance(pnl_24h, dict):
        pnl_value = float(pnl_24h.get("net_usd", pnl_24h.get("pnl", 0.0)) or 0.0)
    elif pnl_24h is not None:
        pnl_value = float(pnl_24h)
    max_loss = float(cfg.get("max_daily_loss_usd", 0) or 0)
    if max_loss > 0 and pnl_value < -max_loss:
        return False, "max_daily_loss"

    consecutive_failures = int(state.get("consecutive_failures", 0) or 0)
    max_consecutive_failures = int(cfg.get("max_consecutive_failures", 0) or 0)
    if max_consecutive_failures and consecutive_failures > max_consecutive_failures:
        return False, "max_consecutive_failures"

    if state.get("rpc_unstable"):
        return False, "rpc_unstable"

    if state.get("ws_both_offline"):
        return False, "ws_offline"

    return True, ""


def is_in_cooldown(now_ts: float) -> bool:
    return bool(_cooldown_until_ts and now_ts < _cooldown_until_ts)


def trigger_kill_switch(reason: str, now_ts: Optional[float] = None) -> None:
    global _cooldown_until_ts, _last_kill_reason, _last_trigger_ts
    if now_ts is None:
        now_ts = time.time()
    cooldown = max(0, _cooldown_minutes) * 60
    _last_trigger_ts = now_ts
    _cooldown_until_ts = now_ts + cooldown
    _last_kill_reason = reason
    log.error("[kill-switch] triggered: %s", reason)


class RiskLimits:
    def __init__(self, config: Dict[str, object], pnl_store: Optional[PnLStore] = None):
        self.config = config or {}
        self.pnl_store = pnl_store
        configure_kill_switch(self.config)

    # ------------------------------------------------------------------
    # Route checks
    # ------------------------------------------------------------------
    def evaluate_route_limits(self, chain: str, route_key: str, now_ts: Optional[float] = None):
        """Basic compatibility shim returning an ok_to_trade mapping."""

        ok, reason = True, None
        route_cfg = self.config.get("risk_limits") if isinstance(self.config.get("risk_limits"), dict) else {}
        max_loss_per_trade = float(route_cfg.get("max_route_loss_usd", 0) or 0)
        if max_loss_per_trade > 0:
            ok = True  # placeholder until simulation-aware integration
        return {"ok_to_trade": ok, "reason": reason}

    # ------------------------------------------------------------------
    # Global checks
    # ------------------------------------------------------------------
    def evaluate_global_limits(self, chain: str, now_ts: float):
        state = {"consecutive_failures": 0, "pnl_24h": 0.0}
        if self.pnl_store:
            state["pnl_24h"] = self.pnl_store.get_24h_pnl()
        ok, reason = evaluate_global_limits(self.pnl_store, state) if self.pnl_store else (True, "")
        return {"ok_to_trade": ok, "reason": reason}

    # ------------------------------------------------------------------
    # Cooldown helpers
    # ------------------------------------------------------------------
    def is_in_cooldown(self, now_ts: float) -> bool:
        return is_in_cooldown(now_ts)

    def trigger_kill_switch(self, reason: str, now_ts: Optional[float] = None) -> None:
        trigger_kill_switch(reason, now_ts)

