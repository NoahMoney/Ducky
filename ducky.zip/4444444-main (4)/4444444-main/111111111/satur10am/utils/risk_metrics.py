from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List


def _get_timestamp(record: dict) -> float:
    ts = record.get("timestamp")
    if isinstance(ts, (int, float)):
        return float(ts)
    if isinstance(ts, str):
        try:
            return float(ts)
        except ValueError:
            try:
                return datetime.fromisoformat(ts).timestamp()
            except Exception:
                return 0.0
    return 0.0


def compute_pnl_summary(trades: List[dict]) -> Dict[str, object]:
    trades_sorted = sorted(trades, key=_get_timestamp)
    gross = 0.0
    gas = 0.0
    net = 0.0
    wins = 0
    losses = 0
    pnl_by_route: Dict[str, Dict[str, object]] = defaultdict(lambda: {"gross_usd": 0.0, "gas_usd": 0.0, "net_usd": 0.0, "trades": 0})

    cumulative = 0.0
    peak = 0.0
    max_drawdown = 0.0

    for trade in trades_sorted:
        g = float(trade.get("gross_usd", 0) or 0)
        gas_cost = float(trade.get("gas_usd", 0) or 0)
        n = float(trade.get("net_usd", g - gas_cost))

        gross += g
        gas += gas_cost
        net += n

        if n > 0:
            wins += 1
        elif n < 0:
            losses += 1

        route_key = trade.get("route_key", "unknown")
        route_bucket = pnl_by_route[route_key]
        route_bucket["gross_usd"] += g
        route_bucket["gas_usd"] += gas_cost
        route_bucket["net_usd"] += n
        route_bucket["trades"] += 1

        cumulative += n
        peak = max(peak, cumulative)
        drawdown = peak - cumulative
        max_drawdown = max(max_drawdown, drawdown)

    total_trades = len(trades_sorted)
    win_rate = (wins / total_trades) if total_trades else 0.0

    return {
        "total_trades": total_trades,
        "wins": wins,
        "losses": losses,
        "win_rate": win_rate,
        "gross_usd": gross,
        "gas_usd": gas,
        "net_usd": net,
        "max_drawdown_usd": max_drawdown,
        "pnl_by_route": dict(pnl_by_route),
    }


def compute_daily_pnl(trades: List[dict]) -> Dict[str, Dict[str, object]]:
    daily: Dict[str, Dict[str, object]] = defaultdict(lambda: {"net_usd": 0.0, "gross_usd": 0.0, "gas_usd": 0.0, "trades": 0})
    for trade in trades:
        ts = _get_timestamp(trade)
        dt = datetime.fromtimestamp(ts, tz=timezone.utc)
        key = dt.strftime("%Y-%m-%d")
        g = float(trade.get("gross_usd", 0) or 0)
        gas_cost = float(trade.get("gas_usd", 0) or 0)
        n = float(trade.get("net_usd", g - gas_cost))
        bucket = daily[key]
        bucket["gross_usd"] += g
        bucket["gas_usd"] += gas_cost
        bucket["net_usd"] += n
        bucket["trades"] += 1
    return dict(daily)

