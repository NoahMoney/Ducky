from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional
from decimal import Decimal


@dataclass
class RouteRecord:
    timestamp: float
    chain: str
    mode: str
    route_key: str
    cycle_tokens: List[str]
    dex_path: List[str]
    amount_in_base: float
    amount_out_base: float
    profit_bps: float
    gross_usd: float
    gas_usd: float
    net_usd: float
    live_verified: bool
    executed: bool
    execution_result: Optional[str] = None
    base_price_usd: Optional[float] = None
    notional_usd: Optional[float] = None


class RouteHistory:
    def __init__(self, data_dir: str = "data", filename: str = "route_history.jsonl") -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / filename

    def _serialize_value(self, value):
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, (list, dict, str, int, float, bool)) or value is None:
            return value
        try:
            return float(value)  # type: ignore[arg-type]
        except Exception:
            return str(value)

    def record(self, record: Dict) -> None:
        payload = dict(record)
        payload.setdefault("timestamp", time.time())
        serialised = {k: self._serialize_value(v) for k, v in payload.items()}
        line = json.dumps(serialised, separators=(',', ':'))
        try:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            # Defensive: ignore write errors to avoid breaking the tick loop
            return

    def _parse_ts(self, raw) -> Optional[float]:
        if isinstance(raw, (int, float)):
            return float(raw)
        if isinstance(raw, str):
            try:
                return float(raw)
            except ValueError:
                try:
                    return datetime.fromisoformat(raw).timestamp()
                except Exception:
                    return None
        return None

    def _iter_records(self) -> Iterable[Dict]:
        if not self.path.exists():
            return []
        records: List[Dict] = []
        try:
            with self.path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                        if isinstance(rec, dict):
                            records.append(rec)
                    except json.JSONDecodeError:
                        # Skip partial/corrupt lines
                        continue
        except Exception:
            return []
        return records

    def get_recent(self, *, chain: str, max_age_sec: float = 86400) -> List[Dict]:
        now = time.time()
        out: List[Dict] = []
        for rec in self._iter_records():
            if rec.get("chain") != chain:
                continue
            ts = self._parse_ts(rec.get("timestamp"))
            if ts is None or now - ts > max_age_sec:
                continue
            out.append(rec)
        return out

    def get_by_route_key(
        self,
        *,
        chain: str,
        route_key: str,
        max_age_sec: float = 86400,
        limit: int = 100,
    ) -> List[Dict]:
        now = time.time()
        out: List[Dict] = []
        for rec in self._iter_records():
            if rec.get("chain") != chain:
                continue
            if rec.get("route_key") != route_key:
                continue
            ts = self._parse_ts(rec.get("timestamp"))
            if ts is None or now - ts > max_age_sec:
                continue
            out.append(rec)
            if len(out) >= limit:
                break
        return out
