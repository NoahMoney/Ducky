from __future__ import annotations

import json
import logging
import os
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Deque, Dict, Optional

log = logging.getLogger(__name__)


class RoutePerformance:
    """Lightweight per-route performance tracker with scoring and bans.

    This class keeps a rolling history of route outcomes and derives a
    size multiplier per route.  Higher scores → larger size, lower
    scores → smaller size, and severely failing routes can be banned.

    Public API (used by the rest of the bot):

        - get_size_multiplier(route_key) -> float
        - adjust_size(route_key, base_amount) -> float
        - is_banned(route_key) -> bool
        - record_trade_outcome(trade: dict) -> None
        - record_simulation_fail(route_key, reason=None) -> None
        - record_mempool_reject(route_key, reason=None) -> None
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        data_path: str | Path | None = None,
        storage_path: str | Path | None = None,
        data_dir: Optional[str] = None,
    ) -> None:
        cfg = config or {}
        rp_cfg = cfg.get("route_performance") if isinstance(cfg.get("route_performance"), dict) else cfg
        rp_cfg = rp_cfg or {}

        # How many recent events per route we remember
        self.history_size = int(rp_cfg.get("history_size", 50))
        # How many consecutive failures before we ban a route
        self.ban_failure_threshold = int(rp_cfg.get("ban_failure_threshold", 7))
        # Clamp range for the internal score / size multiplier
        self.score_min = float(rp_cfg.get("score_min", 0.3))
        self.score_max = float(rp_cfg.get("score_max", 3.0))

        # Determine where to persist ban history
        if storage_path is None and data_path is not None:
            storage_path = data_path
        if storage_path is None:
            if data_dir is not None:
                storage_path = os.path.join(data_dir, "route_performance.jsonl")
            else:
                storage_path = "data/route_performance.jsonl"

        self.path = Path(storage_path)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:  # pragma: no cover - filesystem guard
            log.warning("[route_perf] Failed to ensure data dir %s", self.path.parent)

        # Score state
        self.scores: Dict[str, float] = defaultdict(lambda: 1.0)
        self.failures: Dict[str, int] = defaultdict(int)
        self.history: Dict[str, Deque[dict]] = defaultdict(lambda: deque(maxlen=self.history_size))
        self.banned: Dict[str, dict] = {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _clamp_score(self, value: float) -> float:
        return max(self.score_min, min(self.score_max, value))

    def _bump_score(self, route_key: str, delta: float) -> float:
        current = self.scores[route_key]
        new_score = self._clamp_score(current + delta)
        self.scores[route_key] = new_score
        return new_score

    def _append_history(self, route_key: str, entry: dict) -> None:
        self.history[route_key].append(entry)

    def _check_and_ban(self, route_key: str, reason: str) -> None:
        if self.failures[route_key] < self.ban_failure_threshold:
            return
        now_ts = time.time()
        self.banned[route_key] = {
            "timestamp": now_ts,
            "reason": reason,
            "failures": self.failures[route_key],
        }
        self._persist_ban(route_key, reason, now_ts)
        log.warning(
            "[route_perf] route %s banned after %d failures (%s)",
            route_key,
            self.failures[route_key],
            reason,
        )

    def _persist_ban(self, route_key: str, reason: str, timestamp: float) -> None:
        record = {
            "route_key": route_key,
            "reason": reason,
            "timestamp": timestamp,
            "failures": self.failures[route_key],
        }
        try:
            line = json.dumps(record, default=str)
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except Exception as exc:  # pragma: no cover - filesystem guard
            log.warning("[route_perf] Failed to persist ban record: %s", exc)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get_size_multiplier(self, route_key: str) -> float:
        """Return the current size multiplier for this route."""
        return self.scores.get(route_key, 1.0)

    def get_score(self, route_key: str) -> float:
        """Alias for get_size_multiplier; exposed for clarity if needed."""
        return self.get_size_multiplier(route_key)

    def adjust_size(self, route_key: str, base_amount: float) -> float:
        """Return a position size adjusted by the route's performance score.

        This is the method expected by the multi-hop engine:

            adjusted = route_performance.adjust_size(route_key, amount_in)

        It is intentionally simple and safe:

        - If we have no prior data for the route, multiplier = 1.0.
        - Score is always clamped between score_min and score_max.
        - Negative or zero base_amount is returned unchanged (no magic).
        """
        try:
            amount = float(base_amount)
        except Exception:
            # If something weird is passed in, just return it unchanged
            return base_amount

        if amount <= 0:
            return amount

        multiplier = self.get_size_multiplier(route_key)
        adjusted = amount * multiplier
        log.debug(
            "[route_perf] adjust_size route=%s base=%s mult=%.3f adjusted=%s",
            route_key,
            base_amount,
            multiplier,
            adjusted,
        )
        return adjusted

    def is_banned(self, route_key: str) -> bool:
        ban_meta = self.banned.get(route_key)
        if not ban_meta:
            return False
        return True

    def record_trade_outcome(self, trade: dict) -> None:
        route_key = trade.get("route_key")
        if not route_key:
            return

        status = str(trade.get("status") or "").lower()
        net_usd = float(trade.get("net_usd") or 0.0)
        ts = float(trade.get("timestamp") or time.time())

        delta = 0.0
        failure = False
        if status == "filled":
            if net_usd > 0:
                # Successful, profitable trade → gently boost score
                delta = 0.1
                self.failures[route_key] = 0
            else:
                # Filled but unprofitable → mild penalty
                delta = -0.1
                self.failures[route_key] += 1
        else:
            # Any non-filled status counts as a stronger failure
            delta = -0.2
            failure = True
            self.failures[route_key] += 1

        new_score = self._bump_score(route_key, delta)
        self._append_history(
            route_key,
            {
                "timestamp": ts,
                "status": status,
                "net_usd": net_usd,
                "delta": delta,
                "score": new_score,
            },
        )

        if failure or net_usd <= 0:
            self._check_and_ban(route_key, "trade_failure")

    def record_simulation_fail(self, route_key: str, reason: Optional[str] = None) -> None:
        reason = reason or "simulation_fail"
        self.failures[route_key] += 1
        new_score = self._bump_score(route_key, -0.1)
        self._append_history(
            route_key,
            {
                "timestamp": time.time(),
                "status": reason,
                "net_usd": 0.0,
                "delta": -0.1,
                "score": new_score,
            },
        )
        self._check_and_ban(route_key, reason)

    def record_mempool_reject(self, route_key: str, reason: Optional[str] = None) -> None:
        reason = reason or "mempool_reject"
        self.failures[route_key] += 1
        new_score = self._bump_score(route_key, -0.15)
        self._append_history(
            route_key,
            {
                "timestamp": time.time(),
                "status": reason,
                "net_usd": 0.0,
                "delta": -0.15,
                "score": new_score,
            },
        )
        self._check_and_ban(route_key, reason)
