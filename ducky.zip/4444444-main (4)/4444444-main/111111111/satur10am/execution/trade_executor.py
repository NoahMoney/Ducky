"""Trade execution module for the BSC V2 arbitrage bot.

This executor supports real on-chain execution via the ArbExecutor
smart contract. When ``dry_run`` is enabled it will print simulated
trades for safety instead of submitting transactions.
"""

from __future__ import annotations

import json
import logging
import time
from collections import deque
from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

from web3 import Web3

# Compatible import for different Web3 versions
try:
    # Old Web3 (v5/v6)
    from web3.middleware import geth_poa_middleware
except ImportError:
    try:
        # New Web3 (v7+) – POA middleware moved / renamed
        from web3.middleware.proof_of_authority import (
            ExtraDataToPOAMiddleware as geth_poa_middleware,
        )
    except ImportError:
        # Fallback: no POA middleware available
        geth_poa_middleware = None

from discovery.registry import Registry
from utils.metrics import auto_metrics

log = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    status: str
    success: bool = False
    tx_hash: Optional[str] = None
    error_type: Optional[str] = None
    revert_reason: Optional[str] = None
    error_message: Optional[str] = None
    trade_record: Optional[Dict[str, object]] = None


class RiskManager:
    """Very small in-memory risk guard."""

    def __init__(self, cfg: Dict[str, object]) -> None:
        self.max_notional_usd = Decimal(str(cfg.get("max_notional_per_trade_usd", 0)))
        self.max_trades_per_block = int(cfg.get("max_trades_per_block", 0))
        self.max_trades_per_minute = int(cfg.get("max_trades_per_minute", 0))
        self.max_daily_loss_usd = Decimal(str(cfg.get("max_daily_loss_usd", 0)))

        self._current_block: Optional[int] = None
        self._block_count = 0
        self._minute_trades: deque[float] = deque()
        self._daily_pnl = Decimal(0)

    def _prune_windows(self, now_ts: float) -> None:
        minute_cutoff = now_ts - 60
        while self._minute_trades and self._minute_trades[0] < minute_cutoff:
            self._minute_trades.popleft()

    def evaluate(
        self,
        *,
        amount_in_base: Decimal,
        base_price_usd: Decimal,
        expected_profit_usd: Decimal,
        block_number: Optional[int] = None,
    ) -> Tuple[bool, str]:
        now_ts = time.time()
        self._prune_windows(now_ts)

        notional_usd = amount_in_base * base_price_usd
        if self.max_notional_usd > 0 and notional_usd > self.max_notional_usd:
            return False, f"[risk] Reject: notional {float(notional_usd):.2f} exceeds cap {float(self.max_notional_usd):.2f}"

        if block_number is None:
            block_number = int(now_ts // 3)  # rough bucket when block number unavailable

        if self._current_block != block_number:
            self._current_block = block_number
            self._block_count = 0
        self._block_count += 1
        if self.max_trades_per_block and self._block_count > self.max_trades_per_block:
            return False, f"[risk] Reject: block trade limit exceeded ({self._block_count}/{self.max_trades_per_block})"

        self._minute_trades.append(now_ts)
        if self.max_trades_per_minute and len(self._minute_trades) > self.max_trades_per_minute:
            return False, f"[risk] Reject: minute trade limit exceeded ({len(self._minute_trades)}/{self.max_trades_per_minute})"

        if self.max_daily_loss_usd > 0 and self._daily_pnl - expected_profit_usd < -self.max_daily_loss_usd:
            return False, "[risk] Reject: simulated daily loss limit breached"

        return True, "[risk] OK"


class TradeExecutor:
    """Submit or simulate arbitrage transactions."""

    def __init__(
        self,
        chain_cfg: Dict[str, object],
        dex_configs: Dict[str, Dict[str, object]],
        tokens_config: Dict[str, Dict[str, object]],
        execution_cfg: Dict[str, object],
        registry: Registry,
        route_performance=None,
    ) -> None:
        # Basic chain / config wiring
        self.chain = chain_cfg.get("name", "bsc") if isinstance(chain_cfg, dict) else "bsc"
        self.dex_configs = dex_configs
        self.tokens_config = tokens_config
        self.registry = registry
        self.execution_cfg = execution_cfg

        # Execution behaviour
        self.dry_run_default = bool(execution_cfg.get("dry_run", True))
        self.use_flashloan = bool(execution_cfg.get("use_flashloan", False))
        self.use_arb_executor = bool(execution_cfg.get("use_arb_executor", False))
        self.gas_limit = int(execution_cfg.get("gas_limit", 500000))
        self.gas_strategy_cfg = execution_cfg.get("gas_strategy", {}) or {}
        self.manual_gas_price_gwei = execution_cfg.get("gas_price_gwei")
        self.max_gas_price_gwei = execution_cfg.get("max_gas_price_gwei")
        self.slippage_bps = Decimal(str(execution_cfg.get("slippage_bps", 50)))
        self.submit_mode = str(execution_cfg.get("submit_mode", "public")).lower()
        self.private_rpc = execution_cfg.get("private_rpc")
        self.public_rpc_override = execution_cfg.get("public_rpc")

        self.submitted = 0
        self.dry_runs = 0
        self.last_tx_hash: Optional[str] = None
        self.web3: Optional[Web3] = None
        self.private_web3: Optional[Web3] = None
        self.contract = None
        self.execution_enabled = bool(execution_cfg.get("enabled", False))
        self.route_performance = route_performance
        raw_addr = (
            execution_cfg.get("arb_executor_address")
            or execution_cfg.get("arb_contract")
            or ""
        ).strip()

        # Token lookup tables (symbol → address / decimals)
        self.addr_by_symbol: Dict[str, str] = {}
        self.decimals_by_symbol: Dict[str, int] = {}
        for sym, meta in tokens_config.items():
            addr = meta.get("address")
            dec = meta.get("decimals")
            if isinstance(addr, str) and isinstance(dec, int):
                self.addr_by_symbol[sym] = addr.lower()
                self.decimals_by_symbol[sym] = dec

        if (
            not self.execution_enabled
            or not raw_addr
            or "YourDeployedArbExecutor" in raw_addr
        ):
            log.warning(
                "[executor] No real arb executor address configured; "
                "running in DRY-RUN mode (no on-chain trades will be sent)"
            )
            return

        rpc_urls = chain_cfg.get("rpc_urls") if isinstance(chain_cfg, dict) else []
        provider_url = self.public_rpc_override or (rpc_urls[0] if rpc_urls else None)
        if provider_url:
            self.web3 = Web3(Web3.HTTPProvider(provider_url))
            if geth_poa_middleware is not None:
                try:
                    self.web3.middleware_onion.inject(geth_poa_middleware, layer=0)
                except Exception as exc:
                    print(f"[executor] Failed to inject POA middleware: {exc}")

        if isinstance(self.private_rpc, str) and self.private_rpc:
            try:
                self.private_web3 = Web3(Web3.HTTPProvider(self.private_rpc))
                if geth_poa_middleware is not None:
                    self.private_web3.middleware_onion.inject(geth_poa_middleware, layer=0)
            except Exception as exc:
                log.warning("[executor] Failed to init private provider: %s", exc)

        # Account / signer
        self.account = None
        provider_for_account = self.web3 or self.private_web3
        if provider_for_account:
            privkey = execution_cfg.get("private_key")
            if isinstance(privkey, str) and privkey:
                try:
                    self.account = provider_for_account.eth.account.from_key(privkey)
                except Exception as exc:
                    print(f"[executor] Failed to load account from private key: {exc}")

        # Arb executor contract binding
        provider_for_contract = self.web3 or self.private_web3
        if provider_for_contract:
            abi_path = execution_cfg.get("arb_abi_path")
            try:
                checksum_addr = Web3.to_checksum_address(raw_addr)
            except Exception as exc:
                log.error(
                    "[executor] Invalid arb executor address '%s': %s", raw_addr, exc
                )
                self.contract = None
                self.web3 = None
                return

            if isinstance(abi_path, str):
                try:
                    abi = json.loads(Path(abi_path).read_text())
                    self.contract = provider_for_contract.eth.contract(
                        address=checksum_addr,
                        abi=abi,
                    )
                except FileNotFoundError:
                    print(f"[executor] ABI file not found at {abi_path}")
                except Exception as exc:
                    print(f"[executor] Failed to load contract ABI: {exc}")

    @staticmethod
    def _to_base_units(amount: Decimal, decimals: int) -> int:
        """Convert a human-readable token amount into base units (int)."""
        scale = Decimal(10) ** decimals
        return int((amount * scale).to_integral_value(rounding=ROUND_DOWN))

    def get_gas_price_gwei(self, provider: Web3) -> Optional[Decimal]:
        """Compute a gas price in gwei based on the configured strategy."""

        strategy = self.gas_strategy_cfg or {}
        mode = str(strategy.get("mode", "static")).lower()
        max_gwei_cfg = strategy.get("max_gwei", strategy.get("max_gas_price_gwei"))
        max_gwei = Decimal(str(max_gwei_cfg)) if max_gwei_cfg is not None else None

        try:
            base_price_wei = provider.eth.gas_price
        except Exception:
            base_price_wei = None

        base_gwei = Decimal(base_price_wei) / Decimal(1_000_000_000) if base_price_wei else None

        if mode == "multiplier" and base_gwei is not None:
            mult = Decimal(str(strategy.get("multiplier", 1)))
            price_gwei = base_gwei * mult
        elif mode == "percentile":
            percentile = strategy.get("percentile", 60)
            price_gwei = base_gwei if base_gwei is not None else None
            try:
                fee_history = provider.eth.fee_history(5, "latest", [percentile])
                if fee_history and "reward" in fee_history:
                    rewards = fee_history.get("reward", [])
                    if rewards and rewards[-1]:
                        price_gwei = Decimal(rewards[-1][0]) / Decimal(1_000_000_000)
            except Exception:
                pass
        elif mode == "static":
            static_val = strategy.get("static_gwei")
            if static_val is None:
                static_val = self.manual_gas_price_gwei or 0
            price_gwei = Decimal(str(static_val))
        else:
            price_gwei = base_gwei or (Decimal(str(self.manual_gas_price_gwei)) if self.manual_gas_price_gwei else None)

        if price_gwei is None:
            return None

        if max_gwei is not None and price_gwei > max_gwei:
            log.warning(
                "[executor] Gas price %.3f gwei exceeds cap %.3f gwei; skipping", float(price_gwei), float(max_gwei)
            )
            return None

        return price_gwei

    def _determine_gas_price(self, provider: Web3) -> Optional[int]:
        price_gwei = self.get_gas_price_gwei(provider)
        if price_gwei is None:
            return None
        try:
            return provider.to_wei(price_gwei, "gwei")
        except Exception:
            return None

    def _sign_and_submit(self, tx: Dict[str, object]) -> Optional[str]:
        if not self.account:
            return None

        provider = self.web3 or self.private_web3
        if provider is None:
            return None

        gas_price = self._determine_gas_price(provider)
        if gas_price is None:
            return None

        base_provider = provider
        tx.setdefault("gas", self.gas_limit)
        tx.setdefault("gasPrice", gas_price)
        tx.setdefault("nonce", base_provider.eth.get_transaction_count(self.account.address))
        tx.setdefault("from", self.account.address)
        try:
            tx.setdefault("chainId", base_provider.eth.chain_id)
        except Exception:
            pass

        signed = base_provider.eth.account.sign_transaction(tx, private_key=self.account.key)

        if self.submit_mode == "private" and self.private_web3 is not None:
            send_provider = self.private_web3
            log.info(
                "[exec:%s] Submitting tx (private) gas_price=%.3f gwei endpoint=%s",
                self.chain,
                float(self.get_gas_price_gwei(provider) or 0),
                self.private_rpc,
            )
        else:
            send_provider = base_provider
            log.info(
                "[exec:%s] Submitting tx (public) hash_hint=%s gas_price=%.3f gwei",
                self.chain,
                signed.hash.hex() if hasattr(signed, "hash") else "n/a",
                float(self.get_gas_price_gwei(provider) or 0),
            )

        try:
            tx_hash = send_provider.eth.send_raw_transaction(signed.rawTransaction)
        except Exception as exc:
            log.warning("[exec:%s] Tx submission failed: %s", self.chain, exc)
            return None

        self.last_tx_hash = tx_hash.hex()
        self.submitted += 1
        return self.last_tx_hash

    def build_arb_executor_call(
        self,
        cycle_tokens: Sequence[str],
        dex_path: Sequence[str],
        amount_in: Decimal,
        min_amount_out: Decimal,
        recipient: Optional[str] = None,
    ) -> Optional[Dict[str, object]]:
        """Encode a call to the ArbExecutor contract for a multi-hop trade."""

        if not self.contract:
            return None
        recipient_addr = recipient or (self.account.address if self.account else None)
        if recipient_addr is None:
            return None

        routers = []
        router_overrides = self.execution_cfg.get("routers", {}) if isinstance(self.execution_cfg, dict) else {}
        for dex in dex_path:
            cfg = self.dex_configs.get(dex, {})
            router = router_overrides.get(dex) if isinstance(router_overrides, dict) else None
            if router is None:
                router = cfg.get("router_address") if isinstance(cfg, dict) else None
            if not isinstance(router, str):
                return None
            routers.append(router)

        token_addrs = []
        for sym in cycle_tokens:
            addr = self.addr_by_symbol.get(sym)
            if addr is None:
                return None
            token_addrs.append(addr)

        decimals_in = self.decimals_by_symbol.get(cycle_tokens[0])
        decimals_out = self.decimals_by_symbol.get(cycle_tokens[-1])
        if decimals_in is None or decimals_out is None:
            return None

        amount_in_int = self._to_base_units(amount_in, decimals_in)
        min_out_int = self._to_base_units(min_amount_out, decimals_out)

        data = self.contract.encodeABI(
            fn_name="executeMultiHop",
            args=[token_addrs, routers, amount_in_int, min_out_int, recipient_addr],
        )
        return {"to": self.contract.address, "data": data, "value": 0}

    def execute_trade(
        self,
        path_tokens: Sequence[str],
        dex_path: Sequence[str],
        amount_in: Decimal,
        min_amount_out: Decimal,
        amount_out_est: Optional[Decimal] = None,
        dry_run: bool = True,
        simulation: Optional[Dict[str, object]] = None,
        risk_ok: bool = True,
        pnl_store=None,
        telegram_notifier=None,
    ) -> Dict[str, object]:
        """Execute (or simulate) a multi-hop arbitrage trade."""
        cycle = "/".join(path_tokens)
        dexes = "→".join(dex_path)
        run_dry = dry_run or self.dry_run_default
        route_key = "->".join(path_tokens)

        def _standard_result(
            *,
            status: str,
            success: bool,
            tx_hash: Optional[str] = None,
            error_type: Optional[str] = None,
            error_message: Optional[str] = None,
            trade_record: Optional[Dict[str, object]] = None,
            amount_in_usd: Optional[float] = None,
            amount_out_usd: Optional[float] = None,
            net_usd: Optional[float] = None,
            revert_reason: Optional[str] = None,
        ) -> Dict[str, object]:
            return {
                "success": success,
                "status": status,
                "tx_hash": tx_hash,
                "error_type": error_type,
                "error_message": error_message,
                "revert_reason": revert_reason,
                "chain": self.chain,
                "route_key": route_key,
                "amount_in_usd": amount_in_usd,
                "amount_out_usd": amount_out_usd,
                "net_usd": net_usd,
                "trade_record": trade_record,
            }

        def _record_notifications(trade_record: Optional[Dict[str, object]]) -> None:
            if trade_record is None:
                return
            if pnl_store is not None:
                try:
                    pnl_store.record_trade(trade_record)
                except Exception:
                    log.exception("Failed to record trade")
            if self.route_performance is not None:
                try:
                    self.route_performance.record_trade_outcome(trade_record)
                except Exception:
                    pass
            if telegram_notifier is not None:
                try:
                    telegram_notifier.send_trade_pnl(trade_record)
                except Exception:
                    log.debug("telegram notify failed", exc_info=True)

        try:
            if simulation is not None and not simulation.get("simulation_success", True):
                auto_metrics.inc("executions_failed")
                trade_record = {
                    "timestamp": time.time(),
                    "chain": self.chain,
                    "route_key": route_key,
                    "status": "simulation_failed",
                }
                _record_notifications(trade_record)
                return _standard_result(
                    status="failed",
                    success=False,
                    error_type="validation_fail",
                    error_message="simulation_failed",
                    trade_record=trade_record,
                )
            if not risk_ok:
                auto_metrics.inc("executions_failed")
                trade_record = {
                    "timestamp": time.time(),
                    "chain": self.chain,
                    "route_key": route_key,
                    "status": "risk_blocked",
                }
                _record_notifications(trade_record)
                return _standard_result(
                    status="failed",
                    success=False,
                    error_type="validation_fail",
                    error_message="risk_blocked",
                    trade_record=trade_record,
                )
            if self.route_performance is not None:
                try:
                    if self.route_performance.is_banned(route_key):
                        auto_metrics.inc("routes_banned")
                        auto_metrics.inc("executions_failed")
                        trade_record = {
                            "timestamp": time.time(),
                            "chain": self.chain,
                            "route_key": route_key,
                            "status": "banned",
                        }
                        _record_notifications(trade_record)
                        return _standard_result(
                            status="failed",
                            success=False,
                            error_type="validation_fail",
                            error_message="route_banned",
                            trade_record=trade_record,
                        )
                except Exception:
                    pass
            route_addresses = [self.addr_by_symbol.get(sym) for sym in path_tokens]
            if self.registry and all(route_addresses) and hasattr(
                self.registry, "has_pending_swap_on_route"
            ):
                if self.registry.has_pending_swap_on_route(route_addresses, list(dex_path)):
                    log.info("[mempool] execution blocked: pending swap detected")
                    if self.route_performance is not None:
                        try:
                            self.route_performance.penalize_route(route_key, reason="mempool")
                        except Exception:
                            pass
                    auto_metrics.inc("executions_failed")
                    trade_record = {
                        "timestamp": time.time(),
                        "chain": self.chain,
                        "route_key": route_key,
                        "status": "pending_swap",
                    }
                    _record_notifications(trade_record)
                    return _standard_result(
                        status="failed",
                        success=False,
                        error_type="validation_fail",
                        error_message="pending_swap",
                        trade_record=trade_record,
                    )

            size_mult = Decimal(1)
            if self.route_performance is not None:
                try:
                    size_mult = Decimal(self.route_performance.get_size_multiplier(route_key))
                except Exception:
                    size_mult = Decimal(1)
            if size_mult <= 0:
                auto_metrics.inc("executions_failed")
                trade_record = {
                    "timestamp": time.time(),
                    "chain": self.chain,
                    "route_key": route_key,
                    "status": "performance_pruned",
                }
                _record_notifications(trade_record)
                return _standard_result(
                    status="failed",
                    success=False,
                    error_type="validation_fail",
                    error_message="performance_pruned",
                    trade_record=trade_record,
                )
            amount_in = amount_in * size_mult
            min_amount_out = min_amount_out * size_mult
            if amount_out_est is not None:
                amount_out_est = amount_out_est * size_mult

            slip_fraction = self.slippage_bps / Decimal(10_000)
            computed_min_out = min_amount_out
            if amount_out_est is not None and self.slippage_bps > 0:
                computed_min_out = amount_out_est * (Decimal(1) - slip_fraction)
                min_amount_out = computed_min_out
            log.info(
                "[executor] DRY-RUN: route=%s dexes=%s amount_in=%.6f amount_out_est=%s min_out=%s slippage_bps=%s",
                cycle,
                dexes,
                float(amount_in),
                amount_out_est,
                computed_min_out,
                self.slippage_bps,
            )

            routers = []
            for dex in dex_path:
                cfg = self.dex_configs.get(dex, {})
                router_overrides = self.execution_cfg.get("routers", {})
                router = router_overrides.get(dex) if isinstance(router_overrides, dict) else None
                if router is None:
                    router = cfg.get("router_address") if isinstance(cfg, dict) else None
                if not isinstance(router, str):
                    auto_metrics.inc("executions_failed")
                    return ExecutionResult(
                        status="failed",
                        error_type="missing_router",
                        error_message="missing_router",
                    )
                routers.append(router)

            path_addresses = []
            for sym in path_tokens:
                addr = self.addr_by_symbol.get(sym)
                if addr is None:
                    auto_metrics.inc("executions_failed")
                    return ExecutionResult(
                        status="failed",
                        error_type="unknown_token",
                        error_message="unknown_token",
                    )
                path_addresses.append(addr)

            first_symbol = path_tokens[0]
            decimals_in = self.decimals_by_symbol.get(first_symbol)
            out_symbol = path_tokens[-1]
            decimals_out = self.decimals_by_symbol.get(out_symbol)
            if decimals_in is None or decimals_out is None:
                auto_metrics.inc("executions_failed")
                return ExecutionResult(
                    status="failed",
                    error_type="unknown_decimals",
                    error_message="unknown_decimals",
                )

            amount_in_int = self._to_base_units(amount_in, decimals_in)
            min_amount_out_int = self._to_base_units(min_amount_out, decimals_out)

            if self.contract is None and not run_dry:
                self.dry_runs += 1
                return _standard_result(status="dry_run", success=False)

            if run_dry or not self.contract or not self.account:
                self.dry_runs += 1
                print(
                    f"[EXECUTOR] Dry run on {self.chain}: swap {amount_in} {path_tokens[0]} "
                    f"across {dexes} (cycle {cycle}), min_out={min_amount_out}"
                )
                return _standard_result(status="dry_run", success=False)

            if amount_in_int <= 0 or min_amount_out_int <= 0:
                auto_metrics.inc("executions_failed")
                trade_record = {
                    "timestamp": time.time(),
                    "chain": self.chain,
                    "route_key": route_key,
                    "status": "invalid_amounts",
                }
                _record_notifications(trade_record)
                return _standard_result(
                    status="failed",
                    success=False,
                    error_type="validation_fail",
                    error_message="invalid_amounts",
                    trade_record=trade_record,
                )

            tx_hash = None
            try:
                if self.use_arb_executor and self.contract is not None:
                    fn_call = self.contract.functions.executeMultiHop(
                        path_addresses,
                        routers,
                        amount_in_int,
                        min_amount_out_int,
                        self.account.address,
                    )
                    tx_dict = fn_call.build_transaction({"to": self.contract.address})
                    tx_hash = self._sign_and_submit(tx_dict)
                else:
                    if not hasattr(self.contract.functions, "executeArb"):
                        auto_metrics.inc("executions_failed")
                        trade_record = {
                            "timestamp": time.time(),
                            "chain": self.chain,
                            "route_key": route_key,
                            "status": "missing_method",
                        }
                        _record_notifications(trade_record)
                        return _standard_result(
                            status="failed",
                            success=False,
                            error_type="validation_fail",
                            error_message="missing_method",
                            trade_record=trade_record,
                        )
                    fn_call = self.contract.functions.executeArb(
                        routers,
                        path_addresses,
                        amount_in_int,
                        min_amount_out_int,
                    )
                    tx_dict = fn_call.build_transaction({"to": self.contract.address})
                    tx_hash = self._sign_and_submit(tx_dict)
            except Exception as exc:
                log.exception("[executor] Unexpected error during submission")
                auto_metrics.inc("executions_failed")
                trade_record = {
                    "timestamp": time.time(),
                    "chain": self.chain,
                    "route_key": route_key,
                    "status": "submission_exception",
                    "error_message": str(exc),
                }
                _record_notifications(trade_record)
                return _standard_result(
                    status="failed",
                    success=False,
                    error_type="rpc_error",
                    error_message=str(exc),
                    trade_record=trade_record,
                    revert_reason=str(exc),
                )

            trade_record = {
                "timestamp": time.time(),
                "chain": self.chain,
                "tx_hash": tx_hash,
                "route_key": route_key,
                "tokens": list(path_tokens),
                "dex_path": list(dex_path),
                "size_in": float(amount_in),
                "min_out": float(min_amount_out),
                "status": "submitted" if tx_hash else "failed",
                "simulation_meta": simulation,
            }
            _record_notifications(trade_record)

            if tx_hash:
                print(
                    f"[EXECUTOR] Submitted tx {tx_hash} for cycle {cycle} on {dexes}; "
                    f"min_out={min_amount_out}, amount_in={amount_in}"
                )
                print(
                    f"[METRICS] submitted={self.submitted}, dry_runs={self.dry_runs}, "
                    f"last_tx={self.last_tx_hash}"
                )
            if tx_hash:
                auto_metrics.inc("executions_sent")
            else:
                auto_metrics.inc("executions_failed")
            return _standard_result(
                status="sent" if tx_hash else "failed",
                tx_hash=tx_hash,
                trade_record=trade_record,
                success=bool(tx_hash),
                error_type=None if tx_hash else "rpc_error",
                error_message=None if tx_hash else "tx_submission_failed",
            )
        except Exception as exc:  # pragma: no cover - defensive
            log.exception("[executor] Unhandled error")
            auto_metrics.inc("executions_failed")
            trade_record = {
                "timestamp": time.time(),
                "chain": self.chain,
                "route_key": route_key,
                "status": "exception",
                "error_message": str(exc),
            }
            _record_notifications(trade_record)
            return _standard_result(
                status="failed",
                success=False,
                error_type="rpc_error",
                revert_reason=str(exc),
                error_message=str(exc),
                trade_record=trade_record,
            )

    def notify_route_performance(self, record: Dict[str, object]) -> None:
        if self.route_performance is None:
            return
        try:
            self.route_performance.record_trade(record)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("[executor] Failed to forward record to performance engine: %s", exc)
