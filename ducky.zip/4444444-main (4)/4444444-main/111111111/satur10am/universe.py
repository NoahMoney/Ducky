import json
import logging
from pathlib import Path
from typing import List, Optional

from utils.trending_universe_builder import fetch_dextools_universe_bsc

log = logging.getLogger(__name__)


class UniverseManager:
    """
    Clean DexTools-only universe builder.

    Responsibilities:
      - Load universe config
      - Fetch trending BSC tokens from DexTools
      - Merge with core anchors
      - Cache results (optional)
      - Return final token list

    This replaces all older universe modules:
      * UniverseConfig
      * DailyUniverseSelector
      * dextools_universe_builder
      * dexscreener fallbacks
      * hotpairs sample loaders
    """

    def __init__(self, root_cfg):
        """
        root_cfg = full config.yaml dict (already loaded by main.py)
        """

        uni_cfg = root_cfg.get("universe", {}) or {}
        trending_cfg = uni_cfg.get("trending_universe", {}) or {}
        dex_cfg = trending_cfg.get("dextools", {}) or {}

        self.enabled = bool(uni_cfg.get("enabled", True))
        self.provider = trending_cfg.get("provider", "dextools")

        # DexTools API key
        self.api_key = dex_cfg.get("api_key", "")

        # Universe parameters
        self.max_tokens = int(uni_cfg.get("max_tokens", 50))
        self.min_required = int(uni_cfg.get("min_required_tokens", 20))

        # Anchors
        self.core_anchors = [a.lower() for a in uni_cfg.get("core_anchors", [])]

        # Cache directory
        self.data_dir = Path(uni_cfg.get("data_dir", "universe"))
        self.file_prefix = uni_cfg.get("file_prefix", "universe")
        self.chain_name = root_cfg.get("chain", {}).get("name", "bsc")

        self.cache_file = self.data_dir / f"{self.file_prefix}_{self.chain_name}.json"

    # ------------------------------------------------------------------

    def load_or_build_universe(self) -> List[str]:
        """
        Always rebuild (max_age=0), but still writes cache for debugging.
        """

        if not self.enabled:
            log.warning("[UNIVERSE] Universe disabled via config")
            return []

        self.data_dir.mkdir(parents=True, exist_ok=True)

        log.info(f"[UNIVERSE] Building DexTools-only universe for chain={self.chain_name}")

        tokens = self._build_from_dextools()

        # Append anchors
        for a in self.core_anchors:
            if a not in tokens:
                tokens.append(a)

        log.info(f"[UNIVERSE] Final universe size (dynamic + anchors) = {len(tokens)}")

        # Cache output
        try:
            self.cache_file.write_text(json.dumps(tokens, indent=2))
            log.info(f"[UNIVERSE] Wrote universe cache → {self.cache_file}")
        except Exception as e:
            log.error(f"[UNIVERSE] Failed writing cache: {e}")

        return tokens

    # ------------------------------------------------------------------

    def _build_from_dextools(self) -> List[str]:
        """
        DexTools-only dynamic universe builder.
        """

        if self.provider != "dextools":
            log.error(f"[UNIVERSE] Unsupported provider '{self.provider}' — only 'dextools' allowed")
            return []

        log.info("[UNIVERSE][TRENDING][DEXTOOLS] Fetching trending BSC pools...")

        tokens = fetch_dextools_universe_bsc(
            api_key=self.api_key,
            limit=self.max_tokens,
        )

        if not tokens:
            log.error("[UNIVERSE][TRENDING][DEXTOOLS] Received zero tokens from DexTools")
            return []

        log.info(f"[UNIVERSE][TRENDING][DEXTOOLS] Received {len(tokens)} dynamic tokens")

        if len(tokens) < self.min_required:
            log.warning(
                f"[UNIVERSE][TRENDING][DEXTOOLS] Universe too small "
                f"({len(tokens)} < {self.min_required})"
            )

        return tokens

