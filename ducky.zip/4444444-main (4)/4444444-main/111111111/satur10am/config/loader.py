"""YAML configuration loader with defaults."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import yaml


DEFAULTS = {
    "kill_switch": {
        "enabled": True,
        "max_daily_loss_usd": 300,
        "cooldown_minutes": 60,
        "max_consecutive_failures": 5,
    },
    "pnl": {
        "recent_window_sec": 86_400,
        "max_trades_in_memory": 5_000,
    },
    "route_performance": {
        "history_size": 50,
        "ban_failure_threshold": 7,
        "score_min": 0.3,
        "score_max": 3.0,
    },
    "telemetry": {
        "health_tick_interval": 5,
        "rpc_per_minute_soft_cap": 2000,
    },
}


def _load_yaml(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data


def load_bot_config(path: Path) -> Dict[str, Any]:
    cfg = _load_yaml(path)
    for section, defaults in DEFAULTS.items():
        current = cfg.get(section) or {}
        merged = {**defaults, **current}
        cfg[section] = merged
    return cfg


def load_tokens_config(path: Path) -> Dict[str, Any]:
    return _load_yaml(path)


def dump_config(cfg: Dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        yaml.safe_dump(json.loads(json.dumps(cfg)), fh, sort_keys=False)

