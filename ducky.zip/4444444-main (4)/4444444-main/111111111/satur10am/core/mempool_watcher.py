from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Callable, Dict, List, Optional, Tuple

import websockets
from web3 import Web3

from discovery.registry import Registry
from core.simulation_engine import SwapSimulationEngine, SwapSimulationResult


log = logging.getLogger(__name__)


ROUTER_ABI: List[dict] = [
    {
        "name": "swapExactTokensForTokens",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
    {
        "name": "swapExactTokensForTokensSupportingFeeOnTransferTokens",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "name": "swapExactETHForTokens",
        "type": "function",
        "stateMutability": "payable",
        "inputs": [
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
    {
        "name": "swapExactTokensForETH",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
]


@dataclass
class OverlayEntry:
    chain: str
    dex: str
    pair_address: str
    token0: str
    token1: str
    amounts: Dict[str, int] = field(default_factory=dict)
    last_update_ts: float = field(default_factory=time.time)


@dataclass
class DecodedSwap:
    tx_hash: str
    dex: str
    router: str
    path: List[str]
    amount_in: int


class MempoolWatcher:
    def __init__(
        self,
        rpc_manager,
        chain_config: Dict[str, object],
        dex_configs: Dict[str, Dict[str, object]],
        registry: Optional[Registry] = None,
        tokens_config: Optional[Dict[str, Dict[str, object]]] = None,
        strategy_cfg: Optional[Dict[str, object]] = None,
        logger: Optional[logging.Logger] = None,
        on_profitable_swap_detected: Optional[Callable[[List[str], int, str, SwapSimulationResult], None]] = None,
        simulation_engine: Optional[SwapSimulationEngine] = None,
    ) -> None:
        self.rpc = rpc_manager
        self.chain_config = chain_config or {}
        self.dex_configs = dex_configs or {}
        self.registry = registry
        self.tokens_config = tokens_config or {}
        self.strategy_cfg = strategy_cfg or {}
        self.log = logger or log
        self.on_profitable_swap_detected = on_profitable_swap_detected

        mempool_cfg = self.chain_config.get("mempool", {}) or {}
        self.enabled = bool(mempool_cfg.get("enabled"))
        self.pending_ttl_sec = float(mempool_cfg.get("pending_ttl_sec", 90))
        self.min_notional_usd = float(mempool_cfg.get("min_notional_usd", 0))
        self.max_cached_txs = int(mempool_cfg.get("max_cached_txs", 2000))
        self.ws_url = mempool_cfg.get("ws_rpc") or self.chain_config.get("ws_rpc")
        self.min_amount_in = int(mempool_cfg.get("min_amount_in", 0))
        self.watch_tokens = {addr.lower() for addr in mempool_cfg.get("watch_tokens", []) if isinstance(addr, str)}
        self.watch_pairs = {
            tuple(sorted((a.lower(), b.lower())))
            for a, b in mempool_cfg.get("watch_pairs", [])
            if isinstance(a, str) and isinstance(b, str)
        }
        self.watch_pools = {addr.lower() for addr in mempool_cfg.get("watch_pools", []) if isinstance(addr, str)}
        self.sim_slippage_bps = int(mempool_cfg.get("slippage_bps", 75))
        self.min_profit_usd = float(mempool_cfg.get("min_profit_usd", 0))
        self.sim_gas_limit = int(mempool_cfg.get("gas_limit", 220_000))

        self.router_by_address: Dict[str, str] = {}
        for dex_name, cfg in self.dex_configs.items():
            router_addr = cfg.get("router") or cfg.get("router_address")
            if isinstance(router_addr, str):
                self.router_by_address[router_addr.lower()] = dex_name

        self._overlay: Dict[tuple, OverlayEntry] = {}
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._w3 = Web3()
        self._router_contracts: Dict[str, object] = {}
        self._base_price_cache: Dict[str, Tuple[float, float]] = {}

        self.base_token_symbol = str(self.strategy_cfg.get("base_token", "")).upper()
        self.base_token_address = None
        base_meta = self.tokens_config.get(self.base_token_symbol)
        if isinstance(base_meta, dict):
            addr = base_meta.get("address")
            if isinstance(addr, str):
                self.base_token_address = addr.lower()

        self._simulator = simulation_engine or SwapSimulationEngine(
            rpc_manager,
            price_lookup=self._amount_to_usd,
            slippage_bps=self.sim_slippage_bps,
            gas_limit=self.sim_gas_limit,
            profit_threshold_usd=self.min_profit_usd,
            logger=self.log,
        )

        if not self.enabled or not self.ws_url or not self.router_by_address:
            self.enabled = False

    def start(self) -> None:
        if not self.enabled:
            self.log.info("[mempool] Mempool watcher disabled or no WS endpoint configured")
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="mempool-watcher", daemon=True)
        self._thread.start()
        self.log.info(
            "[mempool:%s] Enabled WebSocket watcher (ttl=%.0fs, min_notional_usd=%.1f)",
            self.chain_config.get("name", "chain"),
            self.pending_ttl_sec,
            self.min_notional_usd,
        )

    def stop(self) -> None:
        self._stop_event.set()
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(lambda: None)
        if self._thread:
            self._thread.join(timeout=2)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get_pool_risk(
        self,
        chain: str,
        dex: str,
        pair_address: str,
    ) -> dict:
        try:
            return self._compute_pool_risk(chain, dex, pair_address)
        except Exception as exc:  # pragma: no cover - defensive
            self.log.warning("[mempool] Risk computation failed for %s/%s: %s", dex, pair_address, exc)
            return {
                "has_pending": False,
                "pending_notional_usd": 0.0,
                "expected_price_impact_bps": 0.0,
                "last_update_ts": 0.0,
            }

    def get_overlay_reserves(
        self,
        chain: str,
        dex: str,
        pair_address: str,
    ) -> Optional[Tuple[int, int]]:
        return None

    # ------------------------------------------------------------------
    # Internal logic
    # ------------------------------------------------------------------
    def _run(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._ws_loop())

    async def _ws_loop(self) -> None:
        backoff = 1.0
        while not self._stop_event.is_set():
            try:
                async with websockets.connect(self.ws_url, ping_interval=20) as ws:
                    subscribe_payload = {
                        "id": 1,
                        "method": "eth_subscribe",
                        "params": ["newPendingTransactions"],
                    }
                    await ws.send(json.dumps(subscribe_payload))
                    backoff = 1.0
                    while not self._stop_event.is_set():
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=5)
                        except asyncio.TimeoutError:
                            continue
                        await self._handle_ws_message(msg)
            except Exception as exc:
                self.log.warning("[mempool] WS loop error: %s", exc)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)

    async def _handle_ws_message(self, msg: str) -> None:
        try:
            data = json.loads(msg)
        except Exception:
            return
        if not isinstance(data, dict):
            return
        params = data.get("params")
        if not isinstance(params, dict):
            return
        result = params.get("result")
        if not isinstance(result, str) or not result.startswith("0x"):
            return
        if self._stop_event.is_set():
            return
        if self._loop:
            asyncio.create_task(self._process_tx_hash(result))

    async def _process_tx_hash(self, tx_hash: str) -> None:
        tx = await self.rpc.call("eth_getTransactionByHash", [tx_hash], timeout=5)
        if not isinstance(tx, dict):
            return
        to_addr = tx.get("to")
        input_data = tx.get("input")
        if not isinstance(to_addr, str) or not isinstance(input_data, str):
            return
        dex = self.router_by_address.get(to_addr.lower())
        if not dex:
            return
        try:
            path, amount_in = self._decode_router_call(dex, input_data, tx)
        except Exception as exc:  # pragma: no cover - defensive
            self.log.debug("[mempool] Failed to decode tx %s: %s", tx_hash, exc)
            return
        if not path or amount_in is None:
            return
        candidate = DecodedSwap(
            tx_hash=tx_hash,
            dex=dex,
            router=to_addr.lower(),
            path=path,
            amount_in=int(amount_in),
        )
        if not self._should_consider_swap(candidate):
            return
        self._accumulate_overlay(self.chain_config.get("name", ""), dex, path, candidate.amount_in)
        await self._evaluate_candidate(candidate)

    def _decode_router_call(self, dex: str, input_data: str, tx: dict) -> Tuple[List[str], Optional[int]]:
        contract = self._router_contracts.get(dex)
        if contract is None:
            router_addr = None
            for addr, name in self.router_by_address.items():
                if name == dex:
                    router_addr = addr
                    break
            if not router_addr:
                return [], None
            contract = self._w3.eth.contract(
                address=self._w3.to_checksum_address(router_addr), abi=ROUTER_ABI
            )
            self._router_contracts[dex] = contract
        func, params = contract.decode_function_input(input_data)
        func_name = getattr(func, "fn_name", "")
        amount_in = None
        path: List[str] = []
        if func_name in {
            "swapExactTokensForTokens",
            "swapExactTokensForTokensSupportingFeeOnTransferTokens",
        }:
            amount_in = int(params.get("amountIn", 0))
            path = [addr.lower() for addr in params.get("path", []) if isinstance(addr, str)]
        elif func_name == "swapExactETHForTokens":
            path = [addr.lower() for addr in params.get("path", []) if isinstance(addr, str)]
            value_raw = tx.get("value")
            if isinstance(value_raw, str) and value_raw.startswith("0x"):
                amount_in = int(value_raw, 16)
        elif func_name == "swapExactTokensForETH":
            amount_in = int(params.get("amountIn", 0))
            path = [addr.lower() for addr in params.get("path", []) if isinstance(addr, str)]
        return path, amount_in

    def _accumulate_overlay(self, chain: str, dex: str, path: List[str], amount_in: int) -> None:
        if self.registry is None:
            return
        if not path or amount_in <= 0:
            return
        for i in range(len(path) - 1):
            token_in = path[i].lower()
            token_out = path[i + 1].lower()
            pair = self.registry.get_pair(chain, dex, token_in, token_out)
            if pair is None:
                continue
            key = (chain, dex, pair.pair.lower())
            with self._lock:
                entry = self._overlay.get(key)
                if entry is None:
                    entry = OverlayEntry(
                        chain=chain,
                        dex=dex,
                        pair_address=pair.pair.lower(),
                        token0=pair.token0.lower(),
                        token1=pair.token1.lower(),
                    )
                    self._overlay[key] = entry
                amounts = entry.amounts
                amounts[token_in] = amounts.get(token_in, 0) + amount_in
                entry.last_update_ts = time.time()
            if len(self._overlay) > self.max_cached_txs:
                self._trim_overlay()

    def _trim_overlay(self) -> None:
        with self._lock:
            items = sorted(self._overlay.items(), key=lambda kv: kv[1].last_update_ts)
            excess = max(0, len(items) - self.max_cached_txs)
            for i in range(excess):
                key, _ = items[i]
                self._overlay.pop(key, None)

    def _cleanup_overlay(self) -> None:
        ttl = self.pending_ttl_sec
        now = time.time()
        with self._lock:
            to_delete = [k for k, v in self._overlay.items() if now - v.last_update_ts > ttl]
            for key in to_delete:
                self._overlay.pop(key, None)

    def _compute_pool_risk(self, chain: str, dex: str, pair_address: str) -> dict:
        if not self.enabled:
            return {
                "has_pending": False,
                "pending_notional_usd": 0.0,
                "expected_price_impact_bps": 0.0,
                "last_update_ts": 0.0,
            }
        self._cleanup_overlay()
        key = (chain, dex, pair_address.lower())
        with self._lock:
            entry = self._overlay.get(key)
        if entry is None:
            return {
                "has_pending": False,
                "pending_notional_usd": 0.0,
                "expected_price_impact_bps": 0.0,
                "last_update_ts": 0.0,
            }
        pair = None
        if self.registry:
            pair = self.registry.get_pair(chain, dex, entry.token0, entry.token1)
        if pair is None:
            return {
                "has_pending": False,
                "pending_notional_usd": 0.0,
                "expected_price_impact_bps": 0.0,
                "last_update_ts": entry.last_update_ts,
            }
        pending_notional_usd = self._estimate_pending_usd(pair, entry.amounts)
        pool_liq = self._estimate_pool_liquidity(pair)
        impact_fraction = 0.0
        if pool_liq and pool_liq > 0:
            impact_fraction = float(pending_notional_usd) / float(pool_liq)
        impact_bps = max(0.0, min(impact_fraction * 10_000, 5000.0))
        return {
            "has_pending": pending_notional_usd > 0,
            "pending_notional_usd": float(pending_notional_usd),
            "expected_price_impact_bps": impact_bps,
            "last_update_ts": entry.last_update_ts,
        }

    def _estimate_pending_usd(self, pair, amounts: Dict[str, int]) -> Decimal:
        total = Decimal(0)
        if self.registry is None:
            return total
        decimals_by_addr = {addr: tok.decimals for addr, tok in self.registry.tokens.items()}
        stable_addrs = {
            addr
            for sym, meta in self.tokens_config.items()
            if sym.upper() in {"USDT", "USDC", "BUSD"}
            for addr in [meta.get("address", "").lower()]
            if isinstance(addr, str)
        }
        price_cache: Dict[str, Decimal] = {}
        for token_addr, raw_amt in amounts.items():
            dec = decimals_by_addr.get(token_addr)
            if dec is None:
                continue
            price = price_cache.get(token_addr)
            if price is None:
                price = self._estimate_token_price_usd(token_addr, pair, stable_addrs)
                if price is None:
                    continue
                price_cache[token_addr] = price
            amount = Decimal(raw_amt) / (Decimal(10) ** dec)
            total += amount * price
        return total

    def _estimate_pool_liquidity(self, pair) -> Optional[Decimal]:
        if self.registry is None:
            return None
        decimals_by_addr = {addr: tok.decimals for addr, tok in self.registry.tokens.items()}
        stable_addrs = {
            addr
            for sym, meta in self.tokens_config.items()
            if sym.upper() in {"USDT", "USDC", "BUSD"}
            for addr in [meta.get("address", "").lower()]
            if isinstance(addr, str)
        }
        base_price = self._get_base_price_usd()
        base_addr = self.base_token_address
        t0 = pair.token0.lower()
        t1 = pair.token1.lower()
        dec0 = decimals_by_addr.get(t0)
        dec1 = decimals_by_addr.get(t1)
        if dec0 is None or dec1 is None:
            return None
        price0 = None
        price1 = None
        if t0 in stable_addrs:
            price0 = Decimal(1)
        if t1 in stable_addrs:
            price1 = Decimal(1)
        if base_addr:
            if t0 == base_addr and base_price:
                price0 = Decimal(base_price)
            if t1 == base_addr and base_price:
                price1 = Decimal(base_price)
        if price0 is None and price1 is not None:
            price0 = self._infer_price(t0, price1, dec0, dec1, pair.reserve0, pair.reserve1)
        elif price1 is None and price0 is not None:
            price1 = self._infer_price(t1, price0, dec1, dec0, pair.reserve1, pair.reserve0)
        if price0 is None or price1 is None:
            return None
        amt0 = Decimal(pair.reserve0) / (Decimal(10) ** dec0)
        amt1 = Decimal(pair.reserve1) / (Decimal(10) ** dec1)
        return amt0 * price0 + amt1 * price1

    def _infer_price(self, token_addr: str, anchor_price: Decimal, dec_token: int, dec_anchor: int, reserve_token: int, reserve_anchor: int) -> Optional[Decimal]:
        if reserve_token <= 0 or reserve_anchor <= 0:
            return None
        token_amt = Decimal(reserve_token) / (Decimal(10) ** dec_token)
        anchor_amt = Decimal(reserve_anchor) / (Decimal(10) ** dec_anchor)
        if token_amt <= 0:
            return None
        return (anchor_amt / token_amt) * anchor_price

    def _estimate_token_price_usd(self, token_addr: str, pair, stable_addrs: set) -> Optional[Decimal]:
        other_addr = pair.token1.lower() if token_addr.lower() == pair.token0.lower() else pair.token0.lower()
        decimals_by_addr = {addr: tok.decimals for addr, tok in self.registry.tokens.items()}
        dec_token = decimals_by_addr.get(token_addr.lower())
        dec_other = decimals_by_addr.get(other_addr)
        if dec_token is None or dec_other is None:
            return None
        other_price = None
        base_price = self._get_base_price_usd()
        if other_addr in stable_addrs:
            other_price = Decimal(1)
        elif self.base_token_address and other_addr == self.base_token_address and base_price:
            other_price = Decimal(base_price)
        if other_price is None:
            return None
        if token_addr.lower() == pair.token0.lower():
            reserve_token = pair.reserve0
            reserve_other = pair.reserve1
        else:
            reserve_token = pair.reserve1
            reserve_other = pair.reserve0
        if reserve_token <= 0 or reserve_other <= 0:
            return None
        token_amt = Decimal(reserve_token) / (Decimal(10) ** dec_token)
        other_amt = Decimal(reserve_other) / (Decimal(10) ** dec_other)
        if token_amt <= 0:
            return None
        return (other_amt / token_amt) * other_price

    def _get_base_price_usd(self) -> Optional[float]:
        if not self.base_token_address or self.registry is None:
            return None
        cache = self._base_price_cache.get(self.base_token_address)
        now = time.time()
        if cache and now - cache[1] < 30:
            return cache[0]
        best_price = None
        best_liq = 0
        stable_addrs = {
            meta.get("address", "").lower()
            for sym, meta in self.tokens_config.items()
            if sym.upper() in {"USDT", "BUSD", "USDC"}
        }
        for stable_addr in stable_addrs:
            pair = None
            for dex_name in self.dex_configs.keys():
                pair = self.registry.get_pair(
                    self.chain_config.get("name", ""),
                    dex_name,
                    self.base_token_address,
                    stable_addr,
                )
                if pair and pair.reserve0 > 0 and pair.reserve1 > 0:
                    break
            if not pair:
                continue
            if pair.token0.lower() == self.base_token_address:
                base_reserve = pair.reserve0
                stable_reserve = pair.reserve1
                stable_dec = self.registry.get_token(stable_addr).decimals if self.registry.get_token(stable_addr) else None
                base_dec = self.registry.get_token(self.base_token_address).decimals if self.registry.get_token(self.base_token_address) else None
            else:
                base_reserve = pair.reserve1
                stable_reserve = pair.reserve0
                stable_dec = self.registry.get_token(stable_addr).decimals if self.registry.get_token(stable_addr) else None
                base_dec = self.registry.get_token(self.base_token_address).decimals if self.registry.get_token(self.base_token_address) else None
            if base_dec is None or stable_dec is None or base_reserve <= 0:
                continue
            base_amt = Decimal(base_reserve) / (Decimal(10) ** base_dec)
            stable_amt = Decimal(stable_reserve) / (Decimal(10) ** stable_dec)
            if base_amt <= 0:
                continue
            price = float(stable_amt / base_amt)
            if price > 0 and max(pair.reserve0, pair.reserve1) > best_liq:
                best_price = price
                best_liq = max(pair.reserve0, pair.reserve1)
        if best_price is not None:
            self._base_price_cache[self.base_token_address] = (best_price, now)
        return best_price

    # ------------------------------------------------------------------
    # Profit simulation helpers
    # ------------------------------------------------------------------
    def _should_consider_swap(self, swap: DecodedSwap) -> bool:
        if self.min_amount_in and swap.amount_in < self.min_amount_in:
            return False
        if self.watch_tokens and not any(tok.lower() in self.watch_tokens for tok in swap.path):
            return False
        if self.watch_pairs:
            pairs = {tuple(sorted((swap.path[i].lower(), swap.path[i + 1].lower()))) for i in range(len(swap.path) - 1)}
            if not pairs.intersection(self.watch_pairs):
                return False
        if self.watch_pools and self.registry:
            touched = False
            for i in range(len(swap.path) - 1):
                pair = self.registry.get_pair(
                    self.chain_config.get("name", ""), swap.dex, swap.path[i], swap.path[i + 1]
                )
                if pair and pair.pair.lower() in self.watch_pools:
                    touched = True
                    break
            if self.watch_pools and not touched:
                return False
        return True

    async def _evaluate_candidate(self, swap: DecodedSwap) -> None:
        if not self._simulator:
            return
        try:
            sim_result = await self._simulator.simulate(
                swap.router,
                swap.path,
                swap.amount_in,
                tx_hash=swap.tx_hash,
            )
        except Exception as exc:  # pragma: no cover - defensive
            self.log.debug("[mempool] Simulation failed for %s: %s", swap.tx_hash, exc)
            return
        if not sim_result:
            return
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
        profit = sim_result.profit_usd if sim_result.profit_usd is not None else 0.0
        self.log.info(
            "[mempool:%s] ts=%s tx=%s dex=%s path=%s profit=%.4f usd",
            self.chain_config.get("name", ""),
            ts,
            swap.tx_hash,
            swap.dex,
            "->".join(swap.path),
            profit,
        )
        if self.on_profitable_swap_detected and sim_result.profit_usd is not None:
            try:
                self.on_profitable_swap_detected(swap.path, swap.amount_in, swap.router, sim_result)
            except Exception as exc:  # pragma: no cover - defensive
                self.log.debug("[mempool] swap callback failed for %s: %s", swap.tx_hash, exc)

    def _amount_to_usd(self, token_addr: str, raw_amount: int) -> Optional[float]:
        if self.registry is None or raw_amount <= 0:
            return None
        token = self.registry.get_token(token_addr)
        if token is None:
            return None
        decimals = token.decimals
        unit_price = self._find_anchor_price_usd(token_addr)
        if unit_price is None:
            return None
        amount = Decimal(raw_amount) / (Decimal(10) ** decimals)
        return float(amount * Decimal(unit_price))

    def _find_anchor_price_usd(self, token_addr: str) -> Optional[float]:
        if self.registry is None:
            return None
        stable_addrs = {
            meta.get("address", "").lower()
            for sym, meta in self.tokens_config.items()
            if sym.upper() in {"USDT", "USDC", "BUSD"}
        }
        base_price = self._get_base_price_usd() or 0.0
        decimals_map = {addr: tok.decimals for addr, tok in self.registry.tokens.items()}
        target_dec = decimals_map.get(token_addr.lower())
        if target_dec is None:
            return None
        for pair in self.registry.pairs:
            if token_addr.lower() not in {pair.token0.lower(), pair.token1.lower()}:
                continue
            other = pair.token1 if pair.token0.lower() == token_addr.lower() else pair.token0
            other_dec = decimals_map.get(other.lower())
            if other_dec is None:
                continue
            other_price = None
            if other.lower() in stable_addrs:
                other_price = 1.0
            elif base_price and self.base_token_address and other.lower() == self.base_token_address:
                other_price = base_price
            if other_price is None:
                continue
            if token_addr.lower() == pair.token0.lower():
                reserve_token = pair.reserve0
                reserve_other = pair.reserve1
            else:
                reserve_token = pair.reserve1
                reserve_other = pair.reserve0
            if reserve_token <= 0 or reserve_other <= 0:
                continue
            token_amt = Decimal(reserve_token) / (Decimal(10) ** target_dec)
            other_amt = Decimal(reserve_other) / (Decimal(10) ** other_dec)
            if token_amt <= 0:
                continue
            price = float((other_amt / token_amt) * Decimal(other_price))
            if price > 0:
                return price
        return None
