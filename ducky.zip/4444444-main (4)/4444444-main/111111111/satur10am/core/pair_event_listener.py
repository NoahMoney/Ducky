"""WebSocket listener for V2 pair Sync and Swap events."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Dict, List, Optional, Set

import websockets
from utils.metrics import auto_metrics

SYNC_TOPIC = "0x1c411e9a"
SWAP_TOPIC = "0xd78ad95f"

_last_pair_event_ts: Optional[float] = None


class PairEventListener:
    def __init__(
        self,
        chain: str,
        ws_url: str,
        registry,
        logger: Optional[logging.Logger] = None,
        reconnect_delay: float = 3.0,
    ) -> None:
        self.chain = chain
        self.ws_url = ws_url
        self.registry = registry
        self.log = logger or logging.getLogger(__name__)
        self.reconnect_delay = reconnect_delay
        self._stop_event = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._subscriptions: Set[str] = set()
        self.last_seen_block: Dict[str, int] = {}
        self.ws_events_received = 0
        self.ws_reconnects = 0
        self.running = False

    def subscribe_pairs(self, pair_addresses: List[str]) -> None:
        addrs = {addr.lower() for addr in pair_addresses if isinstance(addr, str)}
        if not addrs:
            return
        self._subscriptions |= addrs
        if self._ws and not self._ws.closed:
            asyncio.create_task(self._send_subscription())

    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop_event = asyncio.Event()
        loop = asyncio.get_running_loop()
        self._task = loop.create_task(self._listen())
        self.running = True

    async def stop(self) -> None:
        self._stop_event.set()
        self.running = False
        if self._ws and not self._ws.closed:
            try:
                await self._ws.close()
            except Exception:
                pass
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=5)
            except asyncio.TimeoutError:
                self._task.cancel()

    async def _send_subscription(self) -> None:
        if not self._ws or self._ws.closed or not self._subscriptions:
            return
        payload = {
            "id": 1,
            "method": "eth_subscribe",
            "params": ["logs", {"address": list(self._subscriptions)}],
        }
        try:
            await self._ws.send(json.dumps(payload))
            self.log.info(
                "[ws:%s] Subscribed to %d pairs", self.chain, len(self._subscriptions)
            )
        except Exception as exc:
            self.log.warning("[ws:%s] Failed to send subscription: %s", self.chain, exc)

    async def _listen(self) -> None:
        backoff = self.reconnect_delay
        while not self._stop_event.is_set():
            slept = False
            try:
                async with websockets.connect(self.ws_url, ping_interval=20) as ws:
                    self._ws = ws
                    self.log.info("[ws:%s] Connected to %s", self.chain, self.ws_url)
                    backoff = self.reconnect_delay
                    if self._subscriptions:
                        await self._send_subscription()
                    while not self._stop_event.is_set():
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=20)
                        except asyncio.TimeoutError:
                            continue
                        except websockets.ConnectionClosed:
                            break
                        await self._handle_message(msg)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self.ws_reconnects += 1
                self.log.warning("[ws:%s] Listener error: %s", self.chain, exc)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
                slept = True
            finally:
                if self._ws:
                    try:
                        await self._ws.close()
                    except Exception:
                        pass
                self._ws = None
            if self._stop_event.is_set():
                break
            if not slept:
                self.ws_reconnects += 1
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
        self.log.info("[ws:%s] Listener stopped", self.chain)

    async def _handle_message(self, msg: str) -> None:
        try:
            data = json.loads(msg)
        except Exception:
            self.log.debug("[ws:%s] Invalid JSON payload", self.chain)
            return
        if not isinstance(data, dict):
            return
        params = data.get("params")
        if not isinstance(params, dict):
            return
        result = params.get("result")
        if not isinstance(result, dict):
            return

        address = result.get("address")
        topics = result.get("topics")
        data_field = result.get("data")
        block_number = self._parse_block_number(result.get("blockNumber"))
        if not isinstance(address, str) or not isinstance(topics, list) or not data_field:
            return
        if not topics:
            return
        topic0 = topics[0]
        address_l = address.lower()
        if topic0.startswith(SYNC_TOPIC):
            self._handle_sync(address_l, data_field, block_number)
        elif topic0.startswith(SWAP_TOPIC):
            self._handle_swap(address_l, data_field, block_number)

    def _handle_sync(self, address: str, data_field: str, block_number: Optional[int]) -> None:
        if not data_field.startswith("0x") or len(data_field) < 2 + 64 * 2:
            return
        try:
            reserve0 = int(data_field[2:66], 16)
            reserve1 = int(data_field[66:130], 16)
        except Exception:
            return
        block = block_number or 0
        global _last_pair_event_ts
        self.ws_events_received += 1
        auto_metrics.inc("ws_pair_events_received")
        _last_pair_event_ts = time.time()
        self.last_seen_block[address] = block
        self.log.debug(
            "[ws:%s] Sync %s r0=%d r1=%d block=%s",
            self.chain,
            address,
            reserve0,
            reserve1,
            block,
        )
        self.registry.update_reserves_from_event(address, reserve0, reserve1, block)

    def _handle_swap(self, address: str, data_field: str, block_number: Optional[int]) -> None:
        if not data_field.startswith("0x") or len(data_field) < 2 + 64 * 4:
            return
        try:
            amount0_in = int(data_field[2:66], 16)
            amount1_in = int(data_field[66:130], 16)
            amount0_out = int(data_field[130:194], 16)
            amount1_out = int(data_field[194:258], 16)
        except Exception:
            return
        delta0 = amount0_in - amount0_out
        delta1 = amount1_in - amount1_out
        block = block_number or 0
        global _last_pair_event_ts
        self.ws_events_received += 1
        auto_metrics.inc("ws_pair_events_received")
        _last_pair_event_ts = time.time()
        self.last_seen_block[address] = block
        self.log.debug(
            "[ws:%s] Swap %s d0=%d d1=%d block=%s",
            self.chain,
            address,
            delta0,
            delta1,
            block,
        )
        self.registry.apply_swap_delta(address, delta0, delta1, block)

    @staticmethod
    def _parse_block_number(raw) -> Optional[int]:
        if raw is None:
            return None
        if isinstance(raw, int):
            return raw
        if isinstance(raw, str):
            try:
                if raw.startswith("0x"):
                    return int(raw, 16)
                return int(raw)
            except Exception:
                return None
        return None


def get_last_pair_event_ts() -> Optional[float]:
    return _last_pair_event_ts
