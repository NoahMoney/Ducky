"""Lightweight swap simulation and profit estimation utilities.

The :class:`SwapSimulationEngine` encapsulates the logic required to
simulate router calls via ``eth_call`` and to apply simple profit
filters.  It is intentionally dependency‑light so it can be unit tested
without spinning up the entire bot stack.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from web3 import Web3

from core.rpc_manager import RPCManager


RouterPriceLookup = Callable[[str, int], Optional[float]]


SIM_ROUTER_ABI: List[dict] = [
    {
        "name": "getAmountsOut",
        "type": "function",
        "stateMutability": "view",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "path", "type": "address[]"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
    {
        "name": "swapExactTokensForTokens",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
]


@dataclass
class SwapSimulationResult:
    router: str
    path: List[str]
    amount_in: int
    expected_amount_out: int
    min_amount_out: int
    gas_cost_wei: int
    profit_usd: Optional[float]
    tx_hash: Optional[str] = None

    @property
    def is_profitable(self) -> bool:
        return self.profit_usd is not None and self.profit_usd > 0


class SwapSimulationEngine:
    def __init__(
        self,
        rpc: RPCManager,
        *,
        price_lookup: Optional[RouterPriceLookup] = None,
        slippage_bps: int = 50,
        gas_limit: int = 220_000,
        profit_threshold_usd: float = 0.0,
        logger=None,
    ) -> None:
        self.rpc = rpc
        self.price_lookup = price_lookup
        self.slippage_bps = max(0, slippage_bps)
        self.gas_limit = max(21_000, gas_limit)
        self.profit_threshold_usd = float(profit_threshold_usd)
        self.log = logger

        self._w3 = Web3()
        self._router_contracts: Dict[str, object] = {}

    async def simulate(
        self, router: str, path: List[str], amount_in: int, tx_hash: Optional[str] = None
    ) -> Optional[SwapSimulationResult]:
        if not router or not path or amount_in <= 0:
            return None
        contract = self._get_router_contract(router)
        amounts = await self._simulate_amounts(contract, amount_in, path)
        if not amounts:
            return None
        amount_out = int(amounts[-1])
        min_amount_out = int(amount_out * (1 - self.slippage_bps / 10_000))
        gas_price = await self._fetch_gas_price()
        gas_cost_wei = int(gas_price * self.gas_limit) if gas_price is not None else 0

        profit_usd = self._estimate_profit_usd(path, amount_in, min_amount_out, gas_cost_wei)
        result = SwapSimulationResult(
            router=router,
            path=path,
            amount_in=amount_in,
            expected_amount_out=amount_out,
            min_amount_out=min_amount_out,
            gas_cost_wei=gas_cost_wei,
            profit_usd=profit_usd,
            tx_hash=tx_hash,
        )
        if profit_usd is not None and profit_usd >= self.profit_threshold_usd:
            return result
        return None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _get_router_contract(self, router: str):
        key = router.lower()
        cached = self._router_contracts.get(key)
        if cached:
            return cached
        contract = self._w3.eth.contract(address=self._w3.to_checksum_address(router), abi=SIM_ROUTER_ABI)
        self._router_contracts[key] = contract
        return contract

    async def _simulate_amounts(self, contract, amount_in: int, path: List[str]) -> Optional[List[int]]:
        # Prefer getAmountsOut; fall back to a static swap call if needed
        for fn_name, args in [
            ("getAmountsOut", [amount_in, path]),
            (
                "swapExactTokensForTokens",
                [amount_in, 0, path, "0x0000000000000000000000000000000000000000", int(time.time()) + 60],
            ),
        ]:
            try:
                data = contract.encodeABI(fn_name=fn_name, args=args)
                raw = await self.rpc.call("eth_call", [
                    {"to": contract.address, "data": data},
                    "latest",
                ])
                if not isinstance(raw, str):
                    continue
                decoded = contract.decode_function_output(fn_name, raw)
                amounts = list(decoded[0]) if decoded else []
                if amounts:
                    return [int(x) for x in amounts]
            except Exception as exc:  # pragma: no cover - defensive
                if self.log:
                    self.log.debug("[sim] %s failed for %s: %s", fn_name, contract.address, exc)
        return None

    async def _fetch_gas_price(self) -> Optional[int]:
        try:
            raw = await self.rpc.call("eth_gasPrice", [])
        except Exception:
            return None
        if isinstance(raw, str) and raw.startswith("0x"):
            try:
                return int(raw, 16)
            except Exception:
                return None
        if isinstance(raw, (int, float)):
            return int(raw)
        return None

    def _estimate_profit_usd(
        self, path: List[str], amount_in: int, min_amount_out: int, gas_cost_wei: int
    ) -> Optional[float]:
        if not self.price_lookup:
            return None
        token_in = path[0]
        token_out = path[-1]
        in_usd = self.price_lookup(token_in, amount_in)
        out_usd = self.price_lookup(token_out, min_amount_out)
        gas_usd = self.price_lookup(token_in, gas_cost_wei)  # assume input token ~ native asset
        if in_usd is None or out_usd is None:
            return None
        return out_usd - in_usd - (gas_usd or 0.0)

