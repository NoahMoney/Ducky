"""Minimal asynchronous JSON‑RPC manager for BSC.

This class provides a small abstraction over HTTP JSON‑RPC requests
using :mod:`asyncio` for concurrency. Single calls via :meth:`call` and
batched ``eth_call`` requests via :meth:`batch` are executed in a thread
pool to keep the event loop responsive while still benefiting from
``requests`` connection pooling.
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from collections import deque
from typing import Any, Dict, Iterable, List, Optional

import requests

from utils.metrics import auto_metrics


class RPCError(Exception):
    """Raised when all configured RPC endpoints fail."""


class RPCManager:
    """Manages a list of JSON‑RPC endpoints with automatic failover.

    The manager maintains a deterministic rotation order through the
    configured RPC URLs.  Each request is attempted against the
    currently active endpoint; on common failure conditions the
    manager will log a message and rotate to the next URL.  When all
    endpoints have been exhausted, the manager will return ``None`` to
    the caller instead of raising an exception.  This allows callers
    (e.g. the factory scanner) to gracefully handle RPC outages and
    continue scanning until endpoints recover.
    """

    def __init__(
        self,
        rpc_urls: Iterable[str],
        *,
        per_minute_soft_cap: int = 2000,
        meltdown_cooldown_sec: int = 30,
        max_failures_before_unstable: int = 10,
    ) -> None:
        urls = list(rpc_urls)
        if not urls:
            raise ValueError("At least one RPC URL must be provided")
        # Preserve the configured order for deterministic rotation; do not
        # shuffle.  The first URL is treated as primary and the rest as
        # backups.  A rotation pointer tracks the currently active URL.
        self.urls: List[str] = list(urls)
        self.current_index: int = 0
        self.session = requests.Session()

        # Circuit breaker / backoff state per endpoint
        self.consecutive_failures: Dict[str, int] = {url: 0 for url in self.urls}
        self.total_failures: Dict[str, int] = {url: 0 for url in self.urls}
        self.last_failure_ts: Dict[str, float] = {url: 0.0 for url in self.urls}
        self.endpoint_backoff: Dict[str, float] = {url: 0.0 for url in self.urls}
        self.circuit_open_until: Dict[str, float] = {url: 0.0 for url in self.urls}

        # Tunables (kept simple and internal so the public API remains unchanged)
        self.failure_threshold = 5
        self.circuit_cooldown = 60.0
        self.max_backoff = 1.5
        self.meltdown_cooldown = float(max(1, meltdown_cooldown_sec))
        self.max_failures_before_unstable = max(1, int(max_failures_before_unstable))

        # Telemetry / safety
        self.per_minute_soft_cap = max(1, int(per_minute_soft_cap))
        self.call_timestamps: deque[float] = deque()
        self.running = True
        self.rpc_calls_total = 0
        self.global_failures: deque[float] = deque()
        self.last_error: Optional[str] = None
        self.meltdown_until: float = 0.0
        self.last_meltdown_log: float = 0.0

    def _post(self, url: str, payload: Any, timeout: float = 10.0) -> Any:
        """Send a JSON‑RPC POST and return the parsed JSON body.

        This helper wraps ``requests.post`` and leaves error handling
        to the caller.  It does not attempt any retry logic by itself.
        """
        headers = {"Content-Type": "application/json"}
        resp = self.session.post(url, data=json.dumps(payload), headers=headers, timeout=timeout)
        # Raise an HTTPError on non‑2xx status so the caller can
        # detect HTTP 429 or 500 responses and rotate accordingly.
        resp.raise_for_status()
        return resp.json()

    def _rotate(self) -> None:
        """Advance the current endpoint index.

        This updates ``self.current_index`` to the next URL in the
        list.  Rotation wraps around when the end of the list is
        reached.  Rotation does not modify the order of ``self.urls``.
        """
        self.current_index = (self.current_index + 1) % len(self.urls)

    def _select_url(self) -> Optional[str]:
        """Return the next available URL, skipping open circuits."""

        tried = 0
        while tried < len(self.urls):
            url = self.urls[self.current_index]
            now = time.time()
            open_until = self.circuit_open_until.get(url, 0)
            if open_until and now < open_until:
                # Skip open circuit, advance pointer
                self._rotate()
                tried += 1
                continue
            if open_until and now >= open_until:
                print(f"[RPC] Re-enabling endpoint {url} after cooldown")
                self.circuit_open_until[url] = 0.0
                self.consecutive_failures[url] = 0
            return url
        return None

    def _record_failure(self, url: str, exc: Exception) -> None:
        self.consecutive_failures[url] = self.consecutive_failures.get(url, 0) + 1
        self.total_failures[url] = self.total_failures.get(url, 0) + 1
        self.last_failure_ts[url] = time.time()
        self.last_error = str(exc)
        now = time.time()
        self.global_failures.append(now)
        while self.global_failures and self.global_failures[0] < now - 60:
            self.global_failures.popleft()
        if self.consecutive_failures[url] >= self.failure_threshold:
            cooldown = self.circuit_cooldown + random.uniform(0, 5)
            self.circuit_open_until[url] = time.time() + cooldown
            print(
                f"[RPC] Circuit open for {url} after {self.failure_threshold} consecutive failures (cooldown={int(cooldown)}s)"
            )
        self._maybe_trigger_meltdown()

    def _record_success(self, url: str) -> None:
        self.consecutive_failures[url] = 0
        self.endpoint_backoff[url] = max(0.0, self.endpoint_backoff.get(url, 0.0) * 0.5)

    def _maybe_trigger_meltdown(self) -> None:
        """Enter cooldown if all endpoints look unhealthy."""

        now = time.time()
        if self.meltdown_until and now < self.meltdown_until:
            return

        # Meltdown heuristic: every endpoint has exceeded the unstable threshold
        # OR the recent global failure buffer is saturated.
        endpoints_over_threshold = all(
            self.consecutive_failures.get(url, 0) >= self.max_failures_before_unstable
            for url in self.urls
        )
        recent_failures = len(self.global_failures)
        global_over_threshold = recent_failures >= self.max_failures_before_unstable * len(self.urls)

        if endpoints_over_threshold or global_over_threshold:
            self.meltdown_until = now + self.meltdown_cooldown
            if now - self.last_meltdown_log > 5:
                print(
                    f"[RPC] Meltdown detected, entering cooldown for {int(self.meltdown_cooldown)}s; skipping new RPC calls"
                )
                self.last_meltdown_log = now

    async def _apply_backoff(self, url: str) -> None:
        delay = min(self.max_backoff, self.endpoint_backoff.get(url, 0.0))
        if delay > 0:
            await asyncio.sleep(delay)

    async def _post_async(self, url: str, payload: Any, timeout: float) -> Any:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._post, url, payload, timeout)

    def _within_cap(self) -> bool:
        now = time.time()
        while self.call_timestamps and self.call_timestamps[0] < now - 60:
            self.call_timestamps.popleft()
        return len(self.call_timestamps) < self.per_minute_soft_cap

    def _record_call(self) -> None:
        self.call_timestamps.append(time.time())
        self.rpc_calls_total += 1
        auto_metrics.inc("rpc_calls")

    def is_unhealthy(self) -> bool:
        """Return ``True`` when RPC endpoints are in meltdown/cooldown or unstable."""

        now = time.time()
        in_cooldown = self.meltdown_until and now < self.meltdown_until
        open_circuits = [url for url, ts in self.circuit_open_until.items() if ts and now < ts]
        unstable = len(open_circuits) >= len(self.urls)
        return bool(in_cooldown or unstable)

    async def call(self, method: str, params: Any, timeout: float = 10.0) -> Any:
        """Send a single JSON‑RPC request with automatic RPC failover.

        The manager attempts the call against the currently active URL.
        If the call fails due to network errors, HTTP errors, invalid
        JSON, or an empty result (``"0x"``), it will rotate to the
        next endpoint and retry.  After all endpoints have been
        attempted once, the function returns ``None`` and logs an
        error.  Callers should handle ``None`` as a failure case.
        """
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        now = time.time()
        if self.meltdown_until and now < self.meltdown_until:
            if now - self.last_meltdown_log > 5:
                print(
                    f"[RPC] Meltdown detected, entering cooldown for {int(self.meltdown_until - now)}s; skipping new RPC calls"
                )
                self.last_meltdown_log = now
            return None
        tries = 0
        last_exc: Optional[Exception] = None
        while tries < len(self.urls) and self.running:
            url = self._select_url()
            if url is None:
                break
            if not self._within_cap():
                await asyncio.sleep(0.05)
                continue
            await self._apply_backoff(url)
            attempted = False
            recorded = False
            try:
                attempted = True
                reply = await self._post_async(url, payload, timeout)
                self._record_call()
                recorded = True
                # Basic JSON structure check
                if not isinstance(reply, dict) or "result" not in reply:
                    raise ValueError("Malformed RPC response")
                result = reply.get("result")
                # Treat empty or zero results as failure to force a rotate
                if result is None or (isinstance(result, str) and result.lower() in {"0x", "0x0"}):
                    raise ValueError("Empty result")
                self._record_success(url)
                return result
            except Exception as exc:
                last_exc = exc
                if attempted and not recorded:
                    self._record_call()
                self._record_failure(url, exc)
                # Determine next endpoint and log rotation
                next_index = (self.current_index + 1) % len(self.urls)
                next_url = self.urls[next_index]
                print(f"[RPC] Switching RPC → {next_url} due to {exc}")
                # Apply adaptive backoff for empty / malformed
                if isinstance(exc, ValueError) and "Empty" in str(exc):
                    self.endpoint_backoff[url] = min(
                        self.max_backoff,
                        max(0.05, self.endpoint_backoff.get(url, 0.0) + 0.1),
                    )
                auto_metrics.inc("rpc_errors", labels={"endpoint": url})
                self._rotate()
                tries += 1
                continue
        # All endpoints exhausted
        print(f"[RPC] All RPC endpoints failed for method {method}")
        if last_exc:
            # Provide last exception information for context
            print(f"[RPC] Last error: {last_exc}")
        return None

    async def batch(
        self,
        calls: List[Dict[str, Any]],
        block: str = "latest",
        timeout: float = 20.0,
    ) -> List[Any]:
        """Send a batch of ``eth_call`` requests with RPC failover.

        The payload is constructed from the provided list of calls and
        dispatched to the current RPC endpoint.  If the entire batch
        fails (e.g. network error, HTTP error, malformed JSON, or all
        results are empty), the manager rotates to the next endpoint
        and retries.  When all endpoints have been attempted the
        function returns an empty list.
        """
        # Pre-build the batch payload outside of the retry loop
        batch_payload = []
        call_ids: List[int] = []
        for idx, call in enumerate(calls):
            cid = int(call.get("id", idx))
            call_ids.append(cid)
            to_addr = call.get("to")
            data = call.get("data")
            params = [{"to": to_addr, "data": data}, block]
            batch_payload.append(
                {
                    "jsonrpc": "2.0",
                    "id": cid,
                    "method": "eth_call",
                    "params": params,
                }
            )

        now = time.time()
        if self.meltdown_until and now < self.meltdown_until:
            if now - self.last_meltdown_log > 5:
                print(
                    f"[RPC] Meltdown detected, entering cooldown for {int(self.meltdown_until - now)}s; skipping new RPC calls"
                )
                self.last_meltdown_log = now
            return []

        tries = 0
        last_exc: Optional[Exception] = None
        while tries < len(self.urls) and self.running:
            url = self._select_url()
            if url is None:
                break
            if not self._within_cap():
                await asyncio.sleep(0.05)
                continue
            await self._apply_backoff(url)
            attempted = False
            recorded = False
            try:
                attempted = True
                reply = await self._post_async(url, batch_payload, timeout)
                self._record_call()
                recorded = True
                # Response must be a list of individual results
                if not isinstance(reply, list):
                    raise ValueError("Malformed batch response")
                result_map = {item.get("id"): item.get("result") for item in reply}
                results = [result_map.get(cid) for cid in call_ids]
                # Check for empty results (all None or '0x'); if so, rotate
                if all((res is None or (isinstance(res, str) and res.lower() in {"0x", "0x0"})) for res in results):
                    raise ValueError("Empty batch results")
                self._record_call()
                self._record_success(url)
                return results
            except Exception as exc:
                last_exc = exc
                if attempted and not recorded:
                    self._record_call()
                self._record_failure(url, exc)
                next_index = (self.current_index + 1) % len(self.urls)
                next_url = self.urls[next_index]
                print(f"[RPC] Switching RPC → {next_url} due to {exc}")
                if isinstance(exc, ValueError) and "Empty" in str(exc):
                    self.endpoint_backoff[url] = min(
                        self.max_backoff,
                        max(0.05, self.endpoint_backoff.get(url, 0.0) + 0.1),
                    )
                auto_metrics.inc("rpc_errors", labels={"endpoint": url})
                self._rotate()
                tries += 1
                continue
        # All endpoints failed
        print("[RPC] All RPC endpoints failed for batch")
        if last_exc:
            print(f"[RPC] Last error: {last_exc}")
        return []

    def get_rpc_stats(self) -> Dict[str, Any]:
        now = time.time()
        while self.call_timestamps and self.call_timestamps[0] < now - 60:
            self.call_timestamps.popleft()

        open_circuits = [url for url, ts in self.circuit_open_until.items() if ts and now < ts]
        unstable = len(open_circuits) >= len(self.urls)

        cooldown_remaining = max(0.0, self.meltdown_until - now) if self.meltdown_until else 0.0

        return {
            "rpc_calls": int(self.rpc_calls_total),
            "calls_last_minute": len(self.call_timestamps),
            "per_endpoint_failures": dict(self.total_failures),
            "open_circuits": open_circuits,
            "unstable": unstable or bool(self.meltdown_until and cooldown_remaining > 0),
            "last_error": self.last_error,
            "fail_count": sum(self.total_failures.values()),
            "in_cooldown": cooldown_remaining > 0,
            "cooldown_remaining": cooldown_remaining,
        }

    def close(self) -> None:
        self.running = False
        try:
            self.session.close()
        except Exception:
            pass
