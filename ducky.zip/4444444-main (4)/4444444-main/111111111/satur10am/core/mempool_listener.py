from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from collections import deque
from typing import Dict, Optional

import websockets
from web3 import Web3

from utils.metrics import auto_metrics

_last_mempool_event_ts: Optional[float] = None

log = logging.getLogger(__name__)


ROUTER_ABI = [
    {
        "name": "swapExactTokensForTokens",
        "type": "function",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
    {
        "name": "swapExactTokensForTokensSupportingFeeOnTransferTokens",
        "type": "function",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "name": "swapExactETHForTokens",
        "type": "function",
        "inputs": [
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
        "stateMutability": "payable",
    },
    {
        "name": "swapExactTokensForETH",
        "type": "function",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [{"name": "amounts", "type": "uint256[]"}],
    },
    {
        "name": "swapExactTokensForETHSupportingFeeOnTransferTokens",
        "type": "function",
        "inputs": [
            {"name": "amountIn", "type": "uint256"},
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "name": "swapExactETHForTokensSupportingFeeOnTransferTokens",
        "type": "function",
        "inputs": [
            {"name": "amountOutMin", "type": "uint256"},
            {"name": "path", "type": "address[]"},
            {"name": "to", "type": "address"},
            {"name": "deadline", "type": "uint256"},
        ],
        "outputs": [],
        "stateMutability": "payable",
    },
]


class MempoolListener:
    def __init__(
        self,
        chain: str,
        ws_url: str,
        registry,
        router_addresses: Dict[str, str],
        rpc_manager,
        logger=None,
        max_tx_fetch_per_min: int = 300,
        expire_seconds: int = 20,
        impact_threshold_pct: float = 1.0,
        ban_sandwich_risk: bool = True,
    ):
        self.chain = chain
        self.ws_url = ws_url
        self.registry = registry
        self.rpc_manager = rpc_manager
        self.router_addresses = {
            k: v.lower() for k, v in (router_addresses or {}).items() if isinstance(v, str)
        }
        self.log = logger or log
        self.max_tx_fetch_per_min = max(1, int(max_tx_fetch_per_min))
        self.expire_seconds = max(1, int(expire_seconds))
        self.impact_threshold_pct = float(impact_threshold_pct)
        self.ban_sandwich_risk = bool(ban_sandwich_risk)

        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._ws = None
        self._fetch_times: deque[float] = deque()
        self._seen_hashes: Dict[str, float] = {}
        self._w3 = Web3()
        self._router_contract = self._w3.eth.contract(abi=ROUTER_ABI)

        self.ws_events_received = 0
        self.mempool_tx_decoded = 0

        # Registry tuning
        if hasattr(self.registry, "pending_ttl_seconds"):
            self.registry.pending_ttl_seconds = float(self.expire_seconds)
        if hasattr(self.registry, "pending_impact_threshold"):
            self.registry.pending_impact_threshold = float(self.impact_threshold_pct)
        if hasattr(self.registry, "register_routers"):
            self.registry.register_routers(self.router_addresses)

    def start(self):
        if not self.ws_url:
            self.log.info("[mempool:%s] WebSocket URL not configured; listener disabled", self.chain)
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="mempool-listener", daemon=True)
        self._thread.start()
        self.log.info(
            "[mempool:%s] starting pending tx listener (limit=%d/min, ttl=%ss)",
            self.chain,
            self.max_tx_fetch_per_min,
            self.expire_seconds,
        )

    def stop(self):
        self._stop_event.set()
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(lambda: None)
        if self._thread:
            self._thread.join(timeout=3)
        self._ws = None
        self.log.info("[mempool:%s] listener stopped", self.chain)

    def _run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._listen_pending())

    async def _listen_pending(self):
        """Subscribe to eth_subscribe:newPendingTransactions."""
        backoff = 1.0
        while not self._stop_event.is_set():
            try:
                async with websockets.connect(self.ws_url, ping_interval=None) as ws:
                    self._ws = ws
                    sub_req = {
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "eth_subscribe",
                        "params": ["newPendingTransactions"],
                    }
                    await ws.send(json.dumps(sub_req))
                    await ws.recv()  # subscription confirmation
                    self.log.info("[mempool:%s] subscribed to pending transactions", self.chain)
                    backoff = 1.0
                    while not self._stop_event.is_set():
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=20)
                        except asyncio.TimeoutError:
                            continue
                        if not isinstance(msg, str):
                            continue
                        global _last_mempool_event_ts
                        _last_mempool_event_ts = time.time()
                        self.ws_events_received += 1
                        auto_metrics.inc("ws_mempool_events_received")
                        try:
                            payload = json.loads(msg)
                        except Exception:
                            continue
                        params = payload.get("params") if isinstance(payload, dict) else None
                        if not params:
                            continue
                        tx_hash = params.get("result")
                        if isinstance(tx_hash, str):
                            await self._process_tx_hash(tx_hash)
            except asyncio.CancelledError:
                break
            except Exception as exc:  # pragma: no cover - network dependent
                self.log.warning("[mempool:%s] websocket error: %s", self.chain, exc)
                await asyncio.sleep(backoff)
                backoff = min(15.0, backoff * 2)
            finally:
                if self._ws:
                    try:
                        await self._ws.close()
                    except Exception:
                        pass
                self._ws = None
        self._ws = None

    async def _process_tx_hash(self, tx_hash: str):
        """Selective eth_getTransactionByHash -> decode router swaps."""

        now = time.time()
        tx_l = tx_hash.lower()
        self.registry.clear_expired_mempool_deltas(now)
        # Deduplicate and prune seen set
        cutoff = now - max(self.expire_seconds * 2, 120)
        for h, ts in list(self._seen_hashes.items()):
            if ts < cutoff:
                self._seen_hashes.pop(h, None)
        if tx_l in self._seen_hashes:
            return

        while self._fetch_times and self._fetch_times[0] < now - 60:
            self._fetch_times.popleft()
        if len(self._fetch_times) >= self.max_tx_fetch_per_min:
            return

        self._fetch_times.append(now)
        self._seen_hashes[tx_l] = now

        tx = await self.rpc_manager.call("eth_getTransactionByHash", [tx_hash])
        if not isinstance(tx, dict):
            return
        to_addr = tx.get("to")
        if not isinstance(to_addr, str):
            return
        to_l = to_addr.lower()
        if to_l not in self.router_addresses.values():
            return
        data = tx.get("input") or tx.get("data")
        if not isinstance(data, str) or len(data) < 10:
            return

        try:
            fn, params = self._router_contract.decode_function_input(data)
        except Exception:
            return

        fn_name = getattr(fn, "fn_name", "")
        if self.ban_sandwich_risk and "SupportingFeeOnTransfer" in fn_name:
            return

        amount_in = None
        amount_out_min = None
        path = None

        if fn_name in (
            "swapExactTokensForTokens",
            "swapExactTokensForTokensSupportingFeeOnTransferTokens",
        ):
            amount_in = params.get("amountIn")
            amount_out_min = params.get("amountOutMin")
            path = params.get("path")
        elif fn_name in (
            "swapExactETHForTokens",
            "swapExactETHForTokensSupportingFeeOnTransferTokens",
        ):
            value = tx.get("value") or 0
            try:
                amount_in = int(value, 16) if isinstance(value, str) else int(value)
            except Exception:
                amount_in = None
            amount_out_min = params.get("amountOutMin")
            path = params.get("path")
        elif fn_name in (
            "swapExactTokensForETH",
            "swapExactTokensForETHSupportingFeeOnTransferTokens",
        ):
            amount_in = params.get("amountIn")
            amount_out_min = params.get("amountOutMin")
            path = params.get("path")
        else:
            return

        if amount_in is None or amount_out_min is None or not isinstance(path, (list, tuple)):
            return
        path_lower = [p.lower() for p in path if isinstance(p, str)]
        if len(path_lower) < 2:
            return

        self.mempool_tx_decoded += 1
        auto_metrics.inc("mempool_tx_decoded")
        self.registry.apply_mempool_tx(
            {
                "path": path_lower,
                "amount_in": int(amount_in),
                "amount_out_min": int(amount_out_min),
                "router": to_l,
                "tx_hash": tx_hash,
                "timestamp": time.time(),
            }
        )
        self.log.info(
            "[mempool:%s] pending swap detected via %s path=%s amount_in=%s",
            self.chain,
            to_l,
            "->".join(path_lower),
            amount_in,
        )


def get_last_mempool_event_ts() -> Optional[float]:
    return _last_mempool_event_ts
