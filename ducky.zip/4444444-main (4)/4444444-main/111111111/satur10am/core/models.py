"""Data models used throughout the arbitrage bot.

These simple dataclasses describe tokens, liquidity pools (pairs)
and quote results.  They are intentionally minimal to avoid
over‑engineering.  AMM math is performed using integer arithmetic to
mirror on‑chain calculations; ``Decimal`` is used for human‑readable
values when presenting results.
"""

from dataclasses import dataclass, field
from decimal import Decimal
from typing import List


@dataclass
class Token:
    """Representation of a BEP20 token.

    Attributes
    ----------
    symbol: str
        Short symbol for the token (e.g. ``WBNB``).
    address: str
        Checksummed BSC address of the token.
    decimals: int
        Number of decimals used by the token contract.
    """

    symbol: str
    address: str
    decimals: int


@dataclass
class Pair:
    """Representation of a V2 liquidity pool.

    Only constant‑product pools are supported.  Reserves are
    represented as raw integer amounts (not adjusted for decimals).
    """

    chain: str
    dex: str
    pair: str
    token0: str
    token1: str
    reserve0: int
    reserve1: int
    liquidity: int
    last_updated: float = 0.0
    last_block: int = 0


@dataclass
class LegResult:
    """Result of a single swap along a path.

    Keeps track of the input/output amounts and which DEX was used.
    """

    token_in: str
    token_out: str
    dex: str
    amount_in: Decimal
    amount_out: Decimal
    reserve_in: Decimal
    reserve_out: Decimal
    amount_in_raw: int = 0
    amount_out_raw: int = 0
    reserve_in_raw: int = 0
    reserve_out_raw: int = 0
    pair_address: str = ""
    pair_last_updated: float = 0.0
    fee_bps: int = 0


@dataclass
class PathQuote:
    """Result of simulating a multi‑hop swap.

    Contains the full path of tokens and DEXes as well as the
    computed output and the per‑leg details.
    """

    path_tokens: List[str]
    dex_path: List[str]
    amount_in: Decimal
    amount_out: Decimal
    spread_fraction: Decimal
    amount_in_raw: int = 0
    amount_out_raw: int = 0
    legs: List[LegResult] = field(default_factory=list)