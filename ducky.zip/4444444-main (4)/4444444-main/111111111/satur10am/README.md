# BSC V2 Arbitrage Bot

This repository contains a **minimalistic arbitrage bot** designed to
identify multi‐hop opportunities across several constant product AMMs on the
Binance Smart Chain (BSC).  Unlike the monolithic codebase the bot
originated from, this project is purpose built: it focuses only on
Uniswap V2‐style pools on BSC and currently supports PancakeSwap V2,
ApeSwap V2 and BabySwap V2.

## Features

* **Config driven** – All chain endpoints, DEXes, tokens and strategy
  parameters live in YAML files under `config/`.  Adjusting the bot for
  different tokens or fee structures requires no code changes.
* **Discovery layer** – A small factory scanner queries the configured
  AMM factories on BSC, fetches pair addresses and reserves and stores
  them in an in‑memory registry.
* **Quote engine** – A simple quoting service implements the constant
  product formula and simulates multi‑hop swaps with per‑leg slippage
  haircuts.
* **Strategy engine** – The multi‑hop engine enumerates cycles of up
  to four legs across the configured token universe, computes the
  potential spread and logs profitable routes.
* **On‑chain execution** – The `TradeExecutor` can call the bundled
  `ArbExecutor` Solidity contract to perform atomic multi‑hop swaps with
  optional flash‑swap funding.  A dry‑run switch remains available for
  safe testing.

## Usage

1. Install the Python dependencies from `requirements.txt`:

   ```bash
   pip install -r requirements.txt
   ```

2. Edit `config/config.yaml` to point at your preferred BSC RPC
   endpoints and adjust strategy parameters such as the base token,
   maximum path length and profit thresholds.  The `execution` section
   now accepts a private key, gas controls and the deployed
   `ArbExecutor` contract address/ABI path.  Toggle `dry_run` in either
   `strategy` or `execution` to simulate without sending transactions.

3. Populate `config/tokens.yaml` with the symbols, addresses and
   decimals of the tokens you are interested in (each entry can be
   disabled with `enabled: false`).  The provided configuration includes
   a few common BSC tokens.

4. Ensure you have deployed `contracts/ArbExecutor.sol` (testnet first
   is strongly recommended) and configured its address in
   `config/config.yaml`.  The bot will use the first configured RPC URL
   for transaction submission.

5. Run the bot from the repository root:

   ```bash
   python bsc_v2_arb_bot/main.py
   ```

On start‑up the bot scans each configured DEX’s factory for the most
recent pools, builds a registry of tokens and reserves and then enters
a loop where it enumerates possible cycles.  Profitable routes are
reported with lines like:

```
[SPREAD] WBNB/USDT/BTCB/WBNB on pancake→ape→pancake = +0.73%
[DETAILS] input=1.0 WBNB → 307.1 USDT → 0.09 BTCB → 1.0073 WBNB
```

## Configuration

The `config/config.yaml` file contains several sections:

* **chain** – RPC endpoints for BSC.
* **dexes** – Factory and router addresses plus fees (in basis points)
  for each supported DEX.  Entries can be toggled with `enabled` to
  quickly disable venues.  Only V2 AMMs on BSC are included.
* **strategy** – Parameters controlling cycle enumeration such as
  maximum path length, minimum profit fraction and the base token
  amount to simulate.
* **risk** – Simple risk controls like global slippage and minimum
  liquidity in USD.  These heuristics are intentionally conservative.
* **execution** – Execution controls such as dry‑run mode, private key,
  ArbExecutor contract address/ABI path, gas price/limit preferences and
  whether to default to the flash‑swap path.

Tokens are defined in `config/tokens.yaml`.  Each entry maps a symbol
to its address and decimals on BSC and can be disabled with an
`enabled` flag.  Only tokens present in this file will be considered
when building cycles.

## Design Rationale

This project deliberately omits all logic related to other chains,
Uniswap V3, DexTools scanning, mempool sniping and legacy research
experiments.  Those components complicated the original codebase and
are irrelevant for a simple BSC arbitrage bot.  The new structure
exposes a clear entry point (`main.py`), groups related functionality
into small modules and uses Python’s type hints and docstrings to aid
readability.  Additional DEXes or chains can be supported by
extending the config files and writing small adapters in the discovery
layer.
