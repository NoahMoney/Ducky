"""Simple in‑memory registry of tokens and V2 liquidity pools.

The registry stores pairs discovered by the factory scanner and
provides lookup helpers for retrieving pools matching a given token
pair.  It does not persist data to disk; if persistence is desired
this module could be extended to write JSON snapshots between scans.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional
from threading import RLock

from core.models import Token, Pair
from core.rpc_manager import RPCManager

SELECTOR_GET_RESERVES = "0x0902f1ac"

log = logging.getLogger(__name__)


class Registry:
    def __init__(self) -> None:
        # Token metadata keyed by lowercased address
        self.tokens: Dict[str, Token] = {}
        # List of all discovered pairs
        self.pairs: List[Pair] = []
        # Fast lookup by pair address
        self.pairs_by_address: Dict[str, Pair] = {}
        self._pair_index_by_address: Dict[str, int] = {}
        # Fast index keyed by (chain, dex, token_lo, token_hi)
        self.pairs_index: Dict[tuple, Pair] = {}
        # Lightweight persistence for scanner checkpoints
        self.scan_state_path: Optional[Path] = None
        self.scan_state: Dict[str, dict] = {}
        self._lock = RLock()
        # Pending swap deltas keyed by pair address (lowercase)
        self.pending_deltas: Dict[str, list] = {}
        self.pending_ttl_seconds: float = 20.0
        self.pending_impact_threshold: float = 0.0
        self._reserves_by_pair: Dict[str, tuple[int, int]] = {}
        self.router_by_address: Dict[str, str] = {}

    # ------------------------------------------------------------------
    # Token handling
    # ------------------------------------------------------------------
    def add_token(self, symbol: str, address: str, decimals: int) -> None:
        addr_l = address.lower()
        # only add if not present; symbol and decimals come from config
        if addr_l not in self.tokens:
            self.tokens[addr_l] = Token(symbol=symbol, address=address, decimals=decimals)

    def get_token(self, address: str) -> Optional[Token]:
        return self.tokens.get(address.lower())

    # ------------------------------------------------------------------
    # Pair handling
    # ------------------------------------------------------------------
    def add_pair(
        self,
        chain: str,
        dex: str,
        pair_address: str,
        token0: str,
        token1: str,
        reserve0: int,
        reserve1: int,
    ) -> None:
        """Add a new V2 pair to the registry.

        Duplicate pairs (same address) are overwritten with the latest
        reserves.  Liquidity is computed as the maximum of the raw
        reserves.
        """
        addr_l = pair_address.lower()
        liquidity = max(reserve0, reserve1)
        pair = Pair(
            chain=chain,
            dex=dex,
            pair=pair_address,
            token0=token0,
            token1=token1,
            reserve0=reserve0,
            reserve1=reserve1,
            liquidity=liquidity,
            last_updated=time.time(),
        )
        with self._lock:
            self._store_pair(pair, addr_l)
            self._reserves_by_pair[addr_l] = (reserve0, reserve1)

    def get_pairs_for_tokens(self, chain: str, dex: str, token_a: str, token_b: str) -> List[Pair]:
        """Return all pairs on a given DEX matching the two tokens.

        The token order in the pair is ignored; pairs are returned where
        ``token0`` and ``token1`` match the input tokens in either order.
        """
        a = token_a.lower()
        b = token_b.lower()
        key = self._pair_key(chain, dex, a, b)
        indexed = self.pairs_index.get(key)
        if indexed:
            return [indexed]

        out: List[Pair] = []
        for p in self.pairs:
            if p.chain != chain or p.dex != dex:
                continue
            t0 = p.token0.lower()
            t1 = p.token1.lower()
            if (t0 == a and t1 == b) or (t0 == b and t1 == a):
                out.append(p)
        return out

    def get_pair(self, chain: str, dex: str, token_a: str, token_b: str) -> Optional[Pair]:
        """Return the indexed pair for the token combination if present."""
        a = token_a.lower()
        b = token_b.lower()
        key = self._pair_key(chain, dex, a, b)
        pair = self.pairs_index.get(key)
        if pair:
            return pair
        candidates = self.get_pairs_for_tokens(chain, dex, a, b)
        if candidates:
            return max(candidates, key=lambda p: p.liquidity)
        return None

    def get_best_pair(self, chain: str, dex: str, token_a: str, token_b: str) -> Optional[Pair]:
        """Return the highest liquidity pair for a token pair on a DEX.

        Returns None if no pool exists.
        """
        return self.get_pair(chain, dex, token_a, token_b)

    def summary(self) -> str:
        """Return a short summary string of the registry contents."""
        return f"{len(self.tokens)} tokens, {len(self.pairs)} V2 pairs"

    def all_pair_addresses(self) -> List[str]:
        with self._lock:
            return [p.pair for p in self.pairs]

    def token_count(self) -> int:
        return len(self.tokens)

    def pair_count(self) -> int:
        return len(self.pairs)

    def dex_pool_count(self, dex: str, chain: str | None = None) -> int:
        """Return the number of pools registered for a DEX (optionally by chain)."""

        return sum(
            1 for pair in self.pairs if pair.dex == dex and (chain is None or pair.chain == chain)
        )

    def _store_pair(self, pair: Pair, addr_l: str | None = None) -> None:
        addr_key = addr_l or pair.pair.lower()
        existing_index = self._pair_index_by_address.get(addr_key)
        if existing_index is None:
            self.pairs.append(pair)
            self._pair_index_by_address[addr_key] = len(self.pairs) - 1
        else:
            self.pairs[existing_index] = pair
        self.pairs_by_address[addr_key] = pair

        key = self._pair_key(pair.chain, pair.dex, pair.token0, pair.token1)
        current = self.pairs_index.get(key)
        if current is None or pair.liquidity >= current.liquidity:
            self.pairs_index[key] = pair

    # ------------------------------------------------------------------
    # Persistence of scan checkpoints
    # ------------------------------------------------------------------
    def load_scan_state(self, path: Path) -> None:
        self.scan_state_path = path
        if not path.exists():
            return
        try:
            self.scan_state = json.loads(path.read_text()) or {}
            log.info("[REGISTRY] Loaded scan state from %s", path)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("[REGISTRY] Failed to load scan state from %s: %s", path, exc)
            self.scan_state = {}

    def persist_scan_state(self) -> None:
        if not self.scan_state_path:
            return
        try:
            self.scan_state_path.write_text(json.dumps(self.scan_state, indent=2))
            log.info("[REGISTRY] Persisted scan state to %s", self.scan_state_path)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("[REGISTRY] Failed to persist scan state: %s", exc)

    # ------------------------------------------------------------------
    # Pending mempool swap overlays
    # ------------------------------------------------------------------
    def register_routers(self, router_map: Dict[str, str]) -> None:
        """Register router address → DEX name mapping for mempool decoding."""

        with self._lock:
            for dex_name, addr in (router_map or {}).items():
                if isinstance(addr, str):
                    self.router_by_address[addr.lower()] = dex_name

    def _cleanup_pending(self, now: Optional[float] = None) -> None:
        now_ts = now or time.time()
        expired_keys = []
        for pair_addr, entries in self.pending_deltas.items():
            filtered = [e for e in entries if e.get("expires_at", 0) > now_ts]
            if filtered:
                self.pending_deltas[pair_addr] = filtered
            else:
                expired_keys.append(pair_addr)
        for key in expired_keys:
            self.pending_deltas.pop(key, None)

    def _find_pair_for_tokens(self, dex: str, token_a: str, token_b: str) -> Optional[Pair]:
        a = token_a.lower()
        b = token_b.lower()
        # Prefer indexed lookup by chain-aware key; fall back to scan
        for pair in self.pairs:
            if pair.dex != dex:
                continue
            t0 = pair.token0.lower()
            t1 = pair.token1.lower()
            if (t0 == a and t1 == b) or (t0 == b and t1 == a):
                return pair
        return None

    def apply_pair_event(self, event: Dict[str, object]) -> None:
        """Lightweight handler for WS events.

        Expected keys: ``address``, ``reserve0``, ``reserve1``, ``delta0``,
        ``delta1``, ``block``.
        """

        address = str(event.get("address", ""))
        block = int(event.get("block", 0)) if event.get("block") is not None else 0
        if "reserve0" in event and "reserve1" in event:
            try:
                r0 = int(event.get("reserve0", 0))
                r1 = int(event.get("reserve1", 0))
            except Exception:
                return
            self.update_reserves_from_event(address, r0, r1, block)
        elif "delta0" in event and "delta1" in event:
            try:
                d0 = int(event.get("delta0", 0))
                d1 = int(event.get("delta1", 0))
            except Exception:
                return
            self.apply_swap_delta(address, d0, d1, block)

    def apply_mempool_tx(self, tx_info: Dict[str, object]) -> None:
        """Register a pending swap delta from mempool decoding."""

        path = tx_info.get("path") or []
        amount_in = tx_info.get("amount_in")
        amount_out_min = tx_info.get("amount_out_min")
        router = tx_info.get("router")
        tx_hash = tx_info.get("tx_hash")
        ts = tx_info.get("timestamp")
        if ts is None:
            ts = time.time()
        expires = ts + self.pending_ttl_seconds
        if not isinstance(path, (list, tuple)) or len(path) < 2:
            return
        try:
            amt_in = int(amount_in)
            amt_out = int(amount_out_min)
        except Exception:
            return
        router_key = str(router or "").lower()
        dex_name = self.router_by_address.get(router_key, router_key)
        with self._lock:
            self._cleanup_pending(ts)
            current_in = amt_in
            for i in range(len(path) - 1):
                token_in = str(path[i]).lower()
                token_out = str(path[i + 1]).lower()
                pair = self._find_pair_for_tokens(dex_name, token_in, token_out)
                if pair is None:
                    break
                deltas = self.pending_deltas.get(pair.pair.lower(), [])
                res0 = pair.reserve0 + sum(d.get("delta0", 0) for d in deltas)
                res1 = pair.reserve1 + sum(d.get("delta1", 0) for d in deltas)
                if res0 <= 0 or res1 <= 0:
                    break
                if pair.token0.lower() == token_in:
                    reserve_in = res0
                    reserve_out = res1
                else:
                    reserve_in = res1
                    reserve_out = res0
                amount_out = (current_in * reserve_out) // max(1, reserve_in + current_in)
                if pair.token0.lower() == token_in:
                    delta0 = current_in
                    delta1 = -amount_out
                else:
                    delta0 = -amount_out
                    delta1 = current_in
                entry = {
                    "delta0": int(delta0),
                    "delta1": int(delta1),
                    "expires_at": expires,
                    "tx_hash": tx_hash,
                }
                key = pair.pair.lower()
                self.pending_deltas.setdefault(key, []).append(entry)
                current_in = amount_out

    def clear_expired_mempool_deltas(self, now_ts_or_block: Optional[float] = None) -> None:
        with self._lock:
            self._cleanup_pending(now_ts_or_block if isinstance(now_ts_or_block, (int, float)) else None)

    def _route_to_components(self, route) -> tuple[list[str], list[str]]:
        if isinstance(route, dict):
            return list(route.get("tokens") or []), list(route.get("dexes") or [])
        if isinstance(route, (list, tuple)) and len(route) == 2:
            return list(route[0] or []), list(route[1] or [])
        return [], []

    def apply_pending_swap(self, path, amount_in, amount_out_min, router, tx_hash):
        """
        Compute predicted reserve impact for every pair in the path.
        Store pending deltas with TTL.
        """

        if not path or len(path) < 2:
            return
        try:
            amt_in = int(amount_in)
            amt_out_min = int(amount_out_min)
        except Exception:
            return

        now_ts = time.time()
        expires_at = now_ts + self.pending_ttl_seconds
        router_key = (router or "").lower()
        dex_name = self.router_by_address.get(router_key, router_key)

        with self._lock:
            self._cleanup_pending(now_ts)

            current_in = amt_in
            for i in range(len(path) - 1):
                token_in = str(path[i]).lower()
                token_out = str(path[i + 1]).lower()
                pair = self._find_pair_for_tokens(dex_name, token_in, token_out)
                if pair is None:
                    break

                res0 = pair.reserve0
                res1 = pair.reserve1
                if res0 <= 0 or res1 <= 0:
                    break

                # Apply existing deltas when projecting this hop
                deltas = self.pending_deltas.get(pair.pair.lower(), [])
                eff0 = res0 + sum(d.get("delta0", 0) for d in deltas)
                eff1 = res1 + sum(d.get("delta1", 0) for d in deltas)
                if eff0 <= 0 or eff1 <= 0:
                    break

                if pair.token0.lower() == token_in:
                    reserve_in = eff0
                    reserve_out = eff1
                else:
                    reserve_in = eff1
                    reserve_out = eff0

                # Constant-product estimate without fees
                amount_out = (current_in * reserve_out) // (reserve_in + current_in)
                if amt_out_min > 0:
                    amount_out = max(amount_out, amt_out_min if i == len(path) - 2 else amount_out)
                if amount_out <= 0:
                    break

                if pair.token0.lower() == token_in:
                    delta0 = current_in
                    delta1 = -amount_out
                else:
                    delta0 = -amount_out
                    delta1 = current_in

                entry = {
                    "delta0": int(delta0),
                    "delta1": int(delta1),
                    "expires_at": expires_at,
                    "tx_hash": tx_hash,
                }
                key = pair.pair.lower()
                self.pending_deltas.setdefault(key, []).append(entry)

                current_in = amount_out

    def get_effective_reserves(self, token_in, token_out, dex_name):
        """Return reserves including pending deltas."""

        with self._lock:
            self._cleanup_pending()
            pair = self._find_pair_for_tokens(dex_name, token_in, token_out)
            if pair is None:
                return None
            key = pair.pair.lower()
            base0, base1 = self._reserves_by_pair.get(key, (pair.reserve0, pair.reserve1))
            deltas = self.pending_deltas.get(key, [])
            res0 = max(0, base0 + sum(d.get("delta0", 0) for d in deltas))
            res1 = max(0, base1 + sum(d.get("delta1", 0) for d in deltas))
            impact_pct = 0.0
            if base0 > 0:
                impact_pct = max(impact_pct, abs(res0 - base0) / base0 * 100)
            if base1 > 0:
                impact_pct = max(impact_pct, abs(res1 - base1) / base1 * 100)
            return pair, res0, res1, impact_pct

    def has_pending_swap_on_route(self, route_tokens, route_dexes=None):
        """Return True if any pair in the route has active pending deltas."""

        tokens, dexes = self._route_to_components(route_tokens if route_dexes is None else (route_tokens, route_dexes))
        if not tokens or not dexes:
            return False
        with self._lock:
            self._cleanup_pending()
            threshold = max(0.0, float(self.pending_impact_threshold))
            for i in range(len(dexes)):
                dex = dexes[i]
                token_in = str(tokens[i]).lower()
                token_out = str(tokens[i + 1]).lower()
                pair = self._find_pair_for_tokens(dex, token_in, token_out)
                if pair is None:
                    continue
                entries = self.pending_deltas.get(pair.pair.lower(), [])
                if not entries:
                    continue
                base0, base1 = self._reserves_by_pair.get(pair.pair.lower(), (pair.reserve0, pair.reserve1))
                res0 = base0 + sum(e.get("delta0", 0) for e in entries)
                res1 = base1 + sum(e.get("delta1", 0) for e in entries)
                impact_pct = 0.0
                if base0 > 0:
                    impact_pct = max(impact_pct, abs(res0 - base0) / base0 * 100)
                if base1 > 0:
                    impact_pct = max(impact_pct, abs(res1 - base1) / base1 * 100)
                if threshold == 0.0 or impact_pct >= threshold:
                    return True
            return False

    def is_route_threatened_by_mempool(self, route) -> bool:
        """Heuristic: consider any pending delta as contention."""

        tokens, dexes = self._route_to_components(route)
        if not tokens or not dexes:
            return False
        with self._lock:
            self._cleanup_pending()
            for i in range(len(dexes)):
                dex = dexes[i]
                token_in = str(tokens[i]).lower()
                token_out = str(tokens[i + 1]).lower()
                pair = self._find_pair_for_tokens(dex, token_in, token_out)
                if pair is None:
                    continue
                entries = self.pending_deltas.get(pair.pair.lower(), [])
                if entries:
                    return True
            return False

    def get_scan_checkpoint(self, dex: str) -> dict:
        return self.scan_state.get(dex, {})

    def update_scan_checkpoint(self, dex: str, *, length: int, scanned_from: int, scanned_to: int) -> None:
        self.scan_state[dex] = {
            "last_all_pairs_length": length,
            "last_scanned_to": scanned_to,
            "last_scanned_from": scanned_from,
            "last_scan_ts": time.time(),
        }
        self.persist_scan_state()

    @staticmethod
    def _pair_key(chain: str, dex: str, token_a: str, token_b: str) -> tuple:
        a = token_a.lower()
        b = token_b.lower()
        lo, hi = (a, b) if a <= b else (b, a)
        return chain, dex, lo, hi

    # ------------------------------------------------------------------
    # Reserve refresh utilities
    # ------------------------------------------------------------------
    async def refresh_reserves(
        self,
        rpc: RPCManager,
        *,
        dex_filter: Optional[set[str]] = None,
        batch_size: int = 30,
        sleep: float = 0.05,
    ) -> None:
        """Refresh reserves for active pools using batched RPC calls."""

        targets = [
            p for p in self.pairs if (dex_filter is None or p.dex in dex_filter)
        ]
        if not targets:
            return

        loop = asyncio.get_event_loop()
        start_ts = loop.time()
        updated = 0

        for offset in range(0, len(targets), batch_size):
            chunk = targets[offset : offset + batch_size]
            calls = [{"to": p.pair, "data": SELECTOR_GET_RESERVES} for p in chunk]
            results = await rpc.batch(calls)
            for pair, raw in zip(chunk, results or []):
                if not isinstance(raw, str) or not raw.startswith("0x") or len(raw) < 194:
                    continue
                try:
                    r0 = int(raw[2:66], 16)
                    r1 = int(raw[66:130], 16)
                except ValueError:
                    continue
                if r0 <= 0 or r1 <= 0:
                    continue
                self.add_pair(
                    chain=pair.chain,
                    dex=pair.dex,
                    pair_address=pair.pair,
                    token0=pair.token0,
                    token1=pair.token1,
                    reserve0=r0,
                    reserve1=r1,
                )
                updated += 1
            if offset + batch_size < len(targets) and sleep > 0:
                await asyncio.sleep(sleep)

        duration = loop.time() - start_ts
        log.info(
            "[REGISTRY] Refreshed %d pools (filter=%s) in %.2fs",
            updated,
            ",".join(sorted(dex_filter)) if dex_filter else "all",
            duration,
        )

    # ------------------------------------------------------------------
    # WebSocket event integration
    # ------------------------------------------------------------------
    def update_reserves_from_event(
        self, pair_address: str, reserve0: int, reserve1: int, block_number: int
    ) -> None:
        addr_l = pair_address.lower()
        with self._lock:
            pair = self.pairs_by_address.get(addr_l)
            if pair is None:
                log.debug("[REGISTRY] Ignoring event for unknown pair %s", pair_address)
                return
            if pair.last_block and block_number and block_number < pair.last_block:
                log.debug(
                    "[REGISTRY] Ignoring stale event for %s (block %s < %s)",
                    pair_address,
                    block_number,
                    pair.last_block,
                )
                return
            liquidity = max(reserve0, reserve1)
            updated = Pair(
                chain=pair.chain,
                dex=pair.dex,
                pair=pair.pair,
                token0=pair.token0,
                token1=pair.token1,
                reserve0=reserve0,
                reserve1=reserve1,
                liquidity=liquidity,
                last_updated=time.time(),
                last_block=block_number or pair.last_block,
            )
            self._store_pair(updated, addr_l)
            self._reserves_by_pair[addr_l] = (reserve0, reserve1)

    def apply_swap_delta(
        self, pair_address: str, delta0: int, delta1: int, block_number: int
    ) -> None:
        addr_l = pair_address.lower()
        with self._lock:
            pair = self.pairs_by_address.get(addr_l)
            if pair is None:
                log.debug("[REGISTRY] Swap event for unknown pair %s", pair_address)
                return
            if pair.last_block and block_number and block_number < pair.last_block:
                log.debug(
                    "[REGISTRY] Ignoring stale swap event for %s (block %s < %s)",
                    pair_address,
                    block_number,
                    pair.last_block,
                )
                return
            new_r0 = max(0, pair.reserve0 + int(delta0))
            new_r1 = max(0, pair.reserve1 + int(delta1))
            liquidity = max(new_r0, new_r1)
            updated = Pair(
                chain=pair.chain,
                dex=pair.dex,
                pair=pair.pair,
                token0=pair.token0,
                token1=pair.token1,
                reserve0=new_r0,
                reserve1=new_r1,
                liquidity=liquidity,
                last_updated=time.time(),
                last_block=block_number or pair.last_block,
            )
            self._store_pair(updated, addr_l)
            self._reserves_by_pair[addr_l] = (new_r0, new_r1)
