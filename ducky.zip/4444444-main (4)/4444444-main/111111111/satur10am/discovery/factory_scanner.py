"""Uniswap V2-style factory scanner for BSC DEXes.

This scanner queries a V2 factory contract (e.g. PancakeSwap V2) to:
- read allPairsLength()
- fetch the latest N pair addresses via allPairs(index)
- for each pair, call token0(), token1(), and getReserves()
- keep only pairs whose tokens are in the tracked token set
"""

from __future__ import annotations

import asyncio
import itertools
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set

from core.rpc_manager import RPCManager
from discovery.registry import Registry
from utils.metrics import auto_metrics


logger = logging.getLogger(__name__)


# Hard-coded 4-byte selectors for Uniswap V2 / Pancake V2 style contracts
SELECTOR_ALL_PAIRS_LENGTH = "0x574f2ba3"  # allPairsLength()
SELECTOR_ALL_PAIRS = "0x1e3dd18b"  # allPairs(uint256)
SELECTOR_GET_PAIR = "0xe6a43905"  # getPair(address,address)
SELECTOR_TOKEN0 = "0x0dfe1681"  # token0()
SELECTOR_TOKEN1 = "0xd21220a7"  # token1()
SELECTOR_GET_RESERVES = "0x0902f1ac"  # getReserves()
SELECTOR_DECIMALS = "0x313ce567"  # decimals()
SELECTOR_SYMBOL = "0x95d89b41"  # symbol()

# Default batch sizes and throttling parameters.  These values are
# conservative and tuned for public BSC RPC endpoints; they can be
# overridden per‑DEX via the configuration file.  See
# ``config/config.yaml`` for examples.  The user requested scanning
# 30 pairs per batch with a 0.07s pause, so we reflect those
# recommendations in the defaults.  The maximum number of pairs is
# kept high unless overridden via configuration.
DEFAULT_BATCH_SIZE = 15
DEFAULT_SLEEP_PER_BATCH = 0.8
DEFAULT_MAX_PAIRS = 50
DEFAULT_FAST_MODE = False
SAFE_TAIL_WINDOW = 20


def _decode_erc20_string(raw: str) -> Optional[str]:
    """Decode a best-effort ERC20 string return value."""

    if not isinstance(raw, str) or not raw.startswith("0x"):
        return None
    try:
        data = bytes.fromhex(raw[2:])
    except ValueError:
        return None

    # Dynamic string: offset (32 bytes) + length (32 bytes) + data
    if len(data) >= 64:
        strlen = int.from_bytes(data[32:64], byteorder="big", signed=False)
        if strlen > 0 and len(data) >= 64 + strlen:
            try:
                return data[64 : 64 + strlen].decode("utf-8", errors="ignore").strip("\x00")
            except Exception:
                return None

    # Static 32-byte string padded with zeros
    try:
        return data.rstrip(b"\x00").decode("utf-8", errors="ignore") or None
    except Exception:
        return None


@dataclass
class FactoryScanner:
    """Scanner for a single V2 factory on BSC."""

    rpc: RPCManager
    chain: str
    dex_name: str
    factory_address: str
    tracked_tokens: Set[str]
    max_pairs: Optional[int] = None
    batch_size: Optional[int] = None
    sleep_per_batch: Optional[float] = None
    max_pairs_per_run: Optional[int] = None
    fast_mode: bool = DEFAULT_FAST_MODE
    min_universe_size: int = 0
    scan_mode: str = "tail"  # full | tail | incremental
    incremental_cooldown: int = 300

    async def _ensure_token_metadata(self, address: str) -> None:
        """Fetch decimals/symbol for a token if missing from registry."""

        addr_l = address.lower()
        if addr_l in getattr(self, "_token_metadata_cache", {}):
            return
        if self.registry.get_token(addr_l):
            # Cache presence to avoid repeat lookups
            self._token_metadata_cache[addr_l] = True
            return

        params_dec = {"to": addr_l, "data": SELECTOR_DECIMALS}
        decimals_raw = await self.rpc.call("eth_call", [params_dec, "latest"])
        decimals: Optional[int] = None
        if isinstance(decimals_raw, str) and decimals_raw.startswith("0x"):
            try:
                decimals = int(decimals_raw, 16)
            except ValueError:
                decimals = None
        if decimals is None:
            logger.warning(
                "[SCAN][%s] Failed to fetch decimals for token %s; skipping token",
                self.dex_name,
                addr_l,
            )
            self._token_metadata_cache[addr_l] = None
            return

        params_sym = {"to": addr_l, "data": SELECTOR_SYMBOL}
        symbol_raw = await self.rpc.call("eth_call", [params_sym, "latest"])
        symbol = _decode_erc20_string(symbol_raw) or f"TKN_{addr_l[2:6]}...{addr_l[-4:]}"

        self.registry.add_token(symbol, addr_l, decimals)
        self._token_metadata_cache[addr_l] = (symbol, decimals)

    async def _call_factory(self, data: str) -> Optional[str]:
        """Low-level eth_call to the factory contract."""
        params = {
            "to": self.factory_address,
            "data": data,
        }
        try:
            self._rpc_requests += 1
            result = await self.rpc.call("eth_call", [params, "latest"])
        except Exception as exc:
            self._rpc_errors += 1
            print(f"[SCAN][{self.dex_name}] eth_call to factory failed: {exc}")
            return None
        if not isinstance(result, str) or not result.startswith("0x"):
            print(f"[SCAN][{self.dex_name}] Unexpected factory result: {result!r}")
            return None
        return result

    async def _get_all_pairs_length(self) -> Optional[int]:
        """Return allPairsLength() from the factory."""
        data = SELECTOR_ALL_PAIRS_LENGTH  # no args
        raw = await self._call_factory(data)
        if raw is None:
            return None
        try:
            length = int(raw, 16)
        except ValueError:
            print(f"[SCAN][{self.dex_name}] Unable to parse allPairsLength: {raw!r}")
            return None
        return length

    def _encode_all_pairs_data(self, index: int) -> str:
        """Encode call data for allPairs(uint256 index)."""
        # selector (4 bytes) + 32-byte big-endian index
        return SELECTOR_ALL_PAIRS + f"{index:064x}"

    async def _fetch_pair_addresses_chunk(self, indices: List[int]) -> List[str]:
        calls: List[Dict[str, Any]] = []
        for i in indices:
            data = self._encode_all_pairs_data(i)
            calls.append({"to": self.factory_address, "data": data})

        try:
            self._rpc_requests += 1
            results = await self.rpc.batch(calls)
        except Exception as exc:
            self._rpc_errors += 1
            print(f"[SCAN][{self.dex_name}] Batch allPairs failed: {exc}")
            return []

        pair_addresses: List[str] = []
        for idx, res in zip(indices, results or []):
            if not isinstance(res, str) or not res.startswith("0x") or len(res) < 66:
                print(f"[SCAN][{self.dex_name}] allPairs({idx}) malformed result: {res!r}")
                continue
            addr_hex = "0x" + res[-40:]
            if addr_hex.lower() == "0x" + "0" * 40:
                continue
            pair_addresses.append(addr_hex)
        return pair_addresses

    async def _fetch_core_pairs(self) -> List[str]:
        """Fetch getPair for combinations of tracked tokens to ensure anchors are present."""

        if not self.tracked_tokens:
            return []

        token_list = list(self.tracked_tokens)
        calls: List[Dict[str, Any]] = []
        combos: List[tuple[str, str]] = []
        for a, b in itertools.combinations(token_list, 2):
            data = SELECTOR_GET_PAIR + a[2:].rjust(64, "0") + b[2:].rjust(64, "0")
            calls.append({"to": self.factory_address, "data": data})
            combos.append((a, b))

        if not calls:
            return []

        try:
            self._rpc_requests += 1
            results = await self.rpc.batch(calls)
        except Exception as exc:
            self._rpc_errors += 1
            print(f"[SCAN][{self.dex_name}] getPair batch failed: {exc}")
            return []

        new_pairs: List[str] = []
        for (a, b), res in zip(combos, results or []):
            if not isinstance(res, str) or not res.startswith("0x") or len(res) < 66:
                continue
            addr_hex = "0x" + res[-40:]
            if addr_hex.lower() == "0x" + "0" * 40:
                continue
            if self.registry.get_pair(self.chain, self.dex_name, a, b):
                continue
            new_pairs.append(addr_hex)
        return new_pairs

    async def _fetch_pair_metadata_chunk(self, pair_addresses: List[str]) -> int:
        """Fetch token0/token1/reserves for each pair and add to registry."""
        # Build batch for token0 and token1
        calls: List[Dict[str, Any]] = []
        pair_for_call: List[str] = []

        for pair in pair_addresses:
            calls.append({"to": pair, "data": SELECTOR_TOKEN0})
            pair_for_call.append(pair)
            calls.append({"to": pair, "data": SELECTOR_TOKEN1})
            pair_for_call.append(pair)

        try:
            self._rpc_requests += 1
            token_results = await self.rpc.batch(calls)
        except Exception as exc:
            self._rpc_errors += 1
            print(f"[SCAN][{self.dex_name}] Batch token fetch failed: {exc}")
            return 0

        # Parse token0/token1
        pair_tokens: Dict[str, Dict[str, str]] = {}
        for pair, raw in zip(pair_for_call, token_results or []):
            if not isinstance(raw, str) or not raw.startswith("0x") or len(raw) < 66:
                print(f"[SCAN][{self.dex_name}] token call malformed for {pair}: {raw!r}")
                continue
            addr = "0x" + raw[-40:]
            entry = pair_tokens.setdefault(pair, {})
            if "token0" not in entry:
                entry["token0"] = addr.lower()
            else:
                entry["token1"] = addr.lower()

        # Filter to pairs whose tokens are tracked (if a universe filter is active)
        filtered_pairs: List[str] = []
        for pair, meta in pair_tokens.items():
            t0 = meta.get("token0")
            t1 = meta.get("token1")
            if not t0 or not t1:
                continue
            # Universe filtering: When tracked_tokens is non‑empty we keep pairs where at least
            # one token is present in the set.  If the set is empty we disable
            # filtering and accept all pairs.
            if self.tracked_tokens:
                if t0 not in self.tracked_tokens and t1 not in self.tracked_tokens:
                    # Log skip for transparency only when filtering is active
                    logger.debug(
                        "[SCAN][%s] Skipping pair; not in universe: token0=%s, token1=%s",
                        self.dex_name,
                        t0,
                        t1,
                    )
                    continue
            filtered_pairs.append(pair)

        if not filtered_pairs:
            return 0

        # Enrich registry with token metadata for any tokens we see that are missing
        tokens_to_enrich: Set[str] = set()
        for pair in filtered_pairs:
            meta = pair_tokens.get(pair) or {}
            for tok in (meta.get("token0"), meta.get("token1")):
                if not tok:
                    continue
                if not self.registry.get_token(tok):
                    tokens_to_enrich.add(tok)

        for tok in tokens_to_enrich:
            await self._ensure_token_metadata(tok)

        # Build batch for getReserves()
        reserve_calls = [{"to": pair, "data": SELECTOR_GET_RESERVES} for pair in filtered_pairs]
        try:
            self._rpc_requests += 1
            reserve_results = await self.rpc.batch(reserve_calls)
        except Exception as exc:
            self._rpc_errors += 1
            print(f"[SCAN][{self.dex_name}] Batch getReserves failed: {exc}")
            return 0

        added = 0
        for pair, raw in zip(filtered_pairs, reserve_results or []):
            meta = pair_tokens.get(pair)
            if meta is None:
                continue
            if not isinstance(raw, str) or not raw.startswith("0x") or len(raw) < 194:
                print(f"[SCAN][{self.dex_name}] getReserves malformed for {pair}: {raw!r}")
                continue
            try:
                r0 = int(raw[2:66], 16)
                r1 = int(raw[66:130], 16)
            except ValueError:
                print(f"[SCAN][{self.dex_name}] getReserves parse error for {pair}: {raw!r}")
                continue
            if r0 == 0 or r1 == 0:
                continue

            self.registry.add_pair(
                chain=self.chain,
                dex=self.dex_name,
                pair_address=pair,
                token0=meta["token0"],
                token1=meta["token1"],
                reserve0=r0,
                reserve1=r1,
            )
            added += 1

        return added

    async def scan(self, registry: Registry) -> None:
        """Scan the factory for recent pairs and populate the registry.

        The scan respects throttling parameters to avoid overloading the
        RPC endpoints.  Pairs are fetched in batches of ``batch_size``
        and a short pause of ``sleep_per_batch`` seconds is inserted
        between each batch.  Only pairs whose tokens intersect the
        tracked token set are kept.  Reserves are fetched for the
        filtered pairs and non-zero pools are registered.
        """
        self.registry = registry
        self._rpc_requests = 0
        self._rpc_errors = 0
        self._token_metadata_cache: Dict[str, object] = {}

        rpc_stats = self.rpc.get_rpc_stats()
        if self.rpc.is_unhealthy() or rpc_stats.get("in_cooldown"):
            logger.warning("[SCAN][%s] RPC unhealthy → skipping scan cycle for this DEX", self.dex_name)
            return

        # Determine effective parameters using defaults when not set
        effective_batch_size = self.batch_size or DEFAULT_BATCH_SIZE
        effective_sleep = self.sleep_per_batch if self.sleep_per_batch is not None else DEFAULT_SLEEP_PER_BATCH
        effective_max_pairs = self.max_pairs_per_run or self.max_pairs or DEFAULT_MAX_PAIRS

        if self.fast_mode:
            effective_sleep = max(0.2, effective_sleep * 0.7)
            effective_max_pairs = min(int(effective_max_pairs * 1.2), DEFAULT_MAX_PAIRS)

        loop = asyncio.get_running_loop()
        start_time = loop.time()

        try:
            length = await self._get_all_pairs_length()
        except Exception as exc:  # pragma: no cover - defensive guard
            logger.warning(
                "[SCAN][%s] allPairsLength() failed; skipping this DEX for this run",
                self.dex_name,
            )
            logger.debug("allPairsLength exception for %s: %s", self.dex_name, exc, exc_info=True)
            return

        if length is None:
            logger.warning(
                "[SCAN][%s] allPairsLength() failed; skipping this DEX for this run",
                self.dex_name,
            )
            return
        if length == 0:
            print(f"[SCAN][{self.dex_name}] allPairsLength() = 0; no pairs")
            return

        checkpoint = self.registry.get_scan_checkpoint(self.dex_name)
        now = time.time()
        end = length
        start = max(0, end - int(effective_max_pairs))
        mode = (self.scan_mode or "tail").lower()
        last_ts = checkpoint.get("last_scan_ts", 0)
        recent = now - last_ts < self.incremental_cooldown if last_ts else False

        if mode == "full":
            start = 0
        elif mode == "incremental" and checkpoint:
            if recent and checkpoint.get("last_all_pairs_length") == length:
                logger.info(
                    "[SCAN][%s] Recent incremental scan detected; skipping re-scan (last_to=%s)",
                    self.dex_name,
                    checkpoint.get("last_scanned_to"),
                )
                return
            prev_to = checkpoint.get("last_scanned_to")
            if isinstance(prev_to, int) and prev_to >= 0 and prev_to < length:
                start = max(prev_to, start)

        print(
            f"[SCAN][{self.dex_name}] allPairsLength={length}, scanning indices [{start}, {end}) mode={mode}"
        )

        min_universe = max(0, int(self.min_universe_size or 0))
        filtering_enabled = bool(self.tracked_tokens) and len(self.tracked_tokens) >= max(1, min_universe)
        if not filtering_enabled:
            logger.warning("[SCAN][%s] Universe too small; skipping filtered scan for now", self.dex_name)
            if SAFE_TAIL_WINDOW > 0:
                end = length
                tail_window = min(SAFE_TAIL_WINDOW, effective_max_pairs, length)
                start = max(0, end - tail_window)
                effective_max_pairs = min(effective_max_pairs, tail_window)
        else:
            print(
                f"[SCAN][{self.dex_name}] Using universe filter (tokens={len(self.tracked_tokens)})"
            )

        print(
            f"[SCAN][{self.dex_name}] Throttle: batch={effective_batch_size} sleep={effective_sleep} max={effective_max_pairs}"
        )

        # Prepare index range in descending order (newest pairs first)
        indices = list(range(end - 1, start - 1, -1))

        raw_pairs = 0
        total_added = 0

        try:
            for offset in range(0, len(indices), effective_batch_size):
                chunk_indices = indices[offset : offset + effective_batch_size]
                if not chunk_indices:
                    continue
                # Fetch pair addresses for this chunk
                pair_addresses = await self._fetch_pair_addresses_chunk(chunk_indices)
                raw_pairs += len(pair_addresses)
                # Fetch metadata for the chunk and register pairs
                added = await self._fetch_pair_metadata_chunk(pair_addresses)
                total_added += added
                # Pause between batches to respect throttling, except after the last batch
                if offset + effective_batch_size < len(indices) and effective_sleep > 0:
                    await asyncio.sleep(effective_sleep)
        except Exception as exc:  # pragma: no cover - defensive guard
            logger.warning(
                "[SCAN][%s] Scan aborted due to error; skipping this DEX for this run: %s",
                self.dex_name,
                exc,
            )
            return

        try:
            core_pair_addresses = await self._fetch_core_pairs()
            if core_pair_addresses:
                added = await self._fetch_pair_metadata_chunk(core_pair_addresses)
                total_added += added
                logger.info(
                    "[SCAN][%s] Added %d core tracked pairs via getPair()", self.dex_name, added
                )
        except Exception:
            logger.debug("[SCAN][%s] Core pair fetch failed", self.dex_name, exc_info=True)

        try:
            self.registry.update_scan_checkpoint(
                self.dex_name,
                length=length,
                scanned_from=start,
                scanned_to=end,
            )
        except Exception:
            logger.debug("[SCAN][%s] Failed to persist scan checkpoint", self.dex_name, exc_info=True)

        duration = loop.time() - start_time
        print(f"[SCAN] {self.dex_name}: {total_added} tracked pairs in {duration:.2f}s (RPC batches: {self._rpc_requests}, errors: {self._rpc_errors})")
        print(
            f"[SCAN] After scan: registry has {self.registry.token_count()} tokens and {self.registry.pair_count()} V2 pairs"
        )
        auto_metrics.inc("rpc_batches", self._rpc_requests)
        auto_metrics.inc("rpc_errors", self._rpc_errors)
