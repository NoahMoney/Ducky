"""Minimal stub for the Web3 library used in the arbitrage bot.

This stub is provided to allow the bot to run in environments where
the real ``web3`` dependency is not installed.  It implements just
enough of the API for the DRY-RUN mode to initialise without
throwing import errors.  The real functionality of Web3 is not
available; any calls beyond the initialisation will likely fail.

If you intend to execute real transactions, install the genuine
``web3`` package instead of this stub.
"""

from __future__ import annotations

from typing import Any, Optional


class HTTPProvider:
    """Placeholder for Web3.HTTPProvider. Does nothing."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.endpoint_uri = args[0] if args else None


class EthAccount:
    """Stub for Web3.eth.account."""

    @staticmethod
    def from_key(key: str) -> None:
        # Return a simple object representing an account; no signing functionality
        return None


class Eth:
    """Stub for Web3.eth interface."""

    def __init__(self) -> None:
        self.account = EthAccount()


class Web3:
    """Simplified Web3 stub that mimics the minimal API used by the bot."""

    HTTPProvider = HTTPProvider

    def __init__(self, provider: Optional[HTTPProvider] = None) -> None:
        self.provider = provider
        self.eth = Eth()

    @staticmethod
    def to_checksum_address(addr: str) -> str:
        # In the real Web3, this would validate and convert addresses. Here we return the input.
        return addr


# Provide a minimal ``middleware`` namespace with expected attributes.  In
# real Web3, geth POA middleware lives under web3.middleware and
# ExtraDataToPOAMiddleware lives in a nested module.  Here we just
# expose None so that conditional imports succeed.

class _MiddlewareModule:
    geth_poa_middleware = None


class _ProofOfAuthorityModule:
    class ExtraDataToPOAMiddleware:
        pass


middleware = _MiddlewareModule()
middleware.proof_of_authority = _ProofOfAuthorityModule()

__all__ = [
    "Web3",
    "HTTPProvider",
    "middleware",
]